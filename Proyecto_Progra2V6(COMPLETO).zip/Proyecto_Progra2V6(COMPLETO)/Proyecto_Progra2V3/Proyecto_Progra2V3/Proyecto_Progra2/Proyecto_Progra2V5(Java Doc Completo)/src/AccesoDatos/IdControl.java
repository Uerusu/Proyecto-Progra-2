
package AccesoDatos;
/**
 * Controlador centralizado de identificadores únicos para todas las entidades del sistema.
 * Gestiona la generación automática e incremental de IDs mediante un archivo de control.
 * 
 * <p>Esta clase garantiza que cada entidad (usuarios, empleados, planillas) tenga
 * un ID único y secuencial, evitando colisiones y manteniendo la integridad referencial.</p>
 * 
 * <p><b>Importante:</b> Esta clase NO debe modificarse una vez en producción,
 * ya que cualquier cambio podría corromper la secuencia de IDs del sistema.</p>
 * 
 * <p><b>Formato del archivo de control:</b></p>
 * <pre>
 * nombreArchivo1=ultimoID
 * nombreArchivo2=ultimoID
 * ...
 * </pre>
 * 
 * @author Saul
 * @version 1.0.0
 * @since 1.0.0
 */


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import Utilidades.NombresArchivos;


public class IdControl {
    /**
     * Ruta y nombre del archivo que almacena los últimos IDs utilizados.
     * Este archivo actúa como registro central de todos los contadores de ID.
     */
    private String archivoControl;
     /**
     * Mapa que asocia cada archivo de datos con su último ID utilizado.
     * Clave: nombre del archivo (ej: "usuarios.txt")
     * Valor: último ID asignado para ese archivo
     */
    private Map<String, Integer> idMap;
    
    /**
     * Constructor que inicializa el controlador de IDs.
     * Carga automáticamente los últimos IDs utilizados desde el archivo de control.
     * 
     * <p>Si el archivo de control no existe, se creará automáticamente.
     * Si existe, se cargarán todos los contadores en memoria.</p>
     * 
     * @throws IOException Si no se puede leer o crear el archivo de control.
     *                     Esto puede indicar problemas de permisos o espacio en disco.
     * @see #loadIds()  
     */
    public IdControl() throws IOException {
        this.archivoControl = NombresArchivos.ID_CONTROL.getNombreArchivo();
        this.idMap = new HashMap<>();
        loadIds();
    }
    /**
     * Carga en memoria todos los contadores de ID desde el archivo de control.
     * Lee cada línea del archivo y pobla el mapa con los valores actuales.
     * 
     * <p>Formato esperado de cada línea: nombreArchivo=ultimoID</p>
     * <p>Ejemplo: usuarios.txt=105</p>
     * 
     * <p><b>Nota:</b> Este método se ejecuta automáticamente en el constructor.
     * No debe invocarse manualmente.</p>
     * 
     * @throws IOException Si el archivo no se puede leer.
     * @throws NumberFormatException Si el formato del ID no es numérico válido.
     * @throws ArrayIndexOutOfBoundsException Si una línea no tiene el formato correcto.
     */
    private void loadIds() throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(archivoControl))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Divide la línea en partes separadas por "=".
                String[] parts = line.split("=");
                // Coloca el nombre del archivo y su ID correspondiente en el mapa.
                idMap.put(parts[0], Integer.valueOf(parts[1]));
            }
        }
    }
     /**
     * Persiste todos los contadores de ID actuales en el archivo de control.
     * Sobrescribe el archivo completamente con los valores actuales en memoria.
     * 
     * <p>Este método se invoca automáticamente después de generar un nuevo ID
     * para asegurar que los cambios se guarden de inmediato.</p>
     * 
     * @throws IOException Si no se puede escribir en el archivo.
     *                     Posibles causas: permisos insuficientes, disco lleno,
     *                     archivo bloqueado por otro proceso.
     */
    private void saveIds() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivoControl))) {
            for (Map.Entry<String, Integer> entry : idMap.entrySet()) {
                writer.write(entry.getKey() + "=" + entry.getValue());
                writer.newLine();
            }
        }
    }
    
     /**
     * Genera y devuelve el siguiente ID disponible para un archivo específico.
     * Incrementa automáticamente el contador y persiste el cambio.
     * 
     * <p><b>Funcionamiento:</b></p>
     * <ol>
     *   <li>Busca el último ID usado para el archivo especificado</li>
     *   <li>Si no existe entrada, inicializa el contador en 0</li>
     *   <li>Incrementa el contador en 1</li>
     *   <li>Guarda el nuevo valor en el archivo de control</li>
     *   <li>Retorna el nuevo ID</li>
     * </ol>
     * 
     * @return Nuevo ID único e incremental para ese archivo.
     * @throws IOException Si no se puede guardar el nuevo ID en el archivo de control.
     * @see #saveIds()
     */
    public synchronized int getNextId(String fileName) throws IOException {

        this.archivoControl = NombresArchivos.ID_CONTROL.getNombreArchivo();
        this.idMap = new HashMap<>();
        loadIds();
        // Obtiene el siguiente ID para el archivo o comienza con 1 si no existe.
        int nextId = idMap.getOrDefault(fileName, 1);
        // Actualiza el mapa con el nuevo ID incrementado.
        idMap.put(fileName, nextId + 1);
        // Guarda los IDs actualizados en el archivo de control.
        saveIds();
        // Devuelve el ID actual (antes de incrementar).
        return nextId;
    }

}
