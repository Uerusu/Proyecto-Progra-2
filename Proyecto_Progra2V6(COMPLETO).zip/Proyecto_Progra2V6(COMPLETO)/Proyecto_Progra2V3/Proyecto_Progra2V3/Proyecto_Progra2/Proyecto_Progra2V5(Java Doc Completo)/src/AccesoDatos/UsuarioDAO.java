package AccesoDatos;
/**
 * Data Access Object (DAO) para la gestión de usuarios del sistema.
 * Proporciona métodos especializados para la búsqueda y validación de credenciales
 * de usuarios almacenados en archivo de texto plano.
 * 
 * <p>Esta clase implementa el patrón DAO específicamente para la entidad Usuario,
 * encapsulando la lógica de acceso a datos y separándola de la lógica de negocio.</p>
 * 
 * <p><b>Formato del archivo usuarios.txt:</b></p>
 * <pre>
 * id,nombre,apellido1,apellido2,email,usuario,password,rol
 * 1,Juan,Pérez,López,juan@email.com,jperez,pass123,Administrador
 * </pre>
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 */
import Entidades.Usuario;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class UsuarioDAO {
      /**
     * Nombre del archivo que contiene los datos de usuarios del sistema.
     * Constante que define la ubicación de la persistencia de usuarios.
     */
    private static final String ARCHIVO = "usuarios.txt";
    
    /**
     * Busca un usuario en el archivo basándose en sus credenciales de acceso.
     * Valida que tanto el nombre de usuario como la contraseña coincidan exactamente.
     * 
     * <p><b>Proceso de búsqueda:</b></p>
     * <ol>
     *   <li>Lee el archivo línea por línea</li>
     *   <li>Omite líneas vacías o mal formadas</li>
     *   <li>Extrae usuario (campo 6) y contraseña (campo 7)</li>
     *   <li>Compara con las credenciales proporcionadas</li>
     *   <li>Si coinciden, crea y retorna un objeto Usuario</li>
     * </ol>
     * 
     * @param usuario Nombre de usuario para autenticación. No debe ser null ni vacío.
     * @param password Contraseña en texto plano. No debe ser null ni vacía.
     * @return Objeto Usuario con los datos completos si las credenciales son válidas,
     *         o null si no se encuentra coincidencia.
     * @throws IOException Si el archivo no existe o no se puede leer.
     * @see #crearUsuario(String[])
     * @see Entidades.Usuario
     */
   public Usuario buscarPorCredenciales(String usuario, String password)
        throws IOException {

    try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO))) {
        String linea;
        while ((linea = br.readLine()) != null) {

            if (linea.trim().isEmpty()) continue;

            String[] datos = linea.split(",");
            if (datos.length < 8) continue;

            String userArchivo = datos[5].trim();
            String passArchivo = datos[6].trim();

            if (userArchivo.equals(usuario) && passArchivo.equals(password)) {
                return crearUsuario(datos);
            }
        }
    }
    return null;
}


   /**
     * Crea una instancia de Usuario a partir de un array de datos.
     * Método auxiliar privado utilizado por buscarPorCredenciales.
     * 
     * <p>Este método solo asigna los campos esenciales para la autenticación:
     * usuario, contraseña y rol. Los demás campos quedan en su estado por defecto.</p>
     * 
     * <p><b>Mapeo de campos:</b></p>
     * <ul>
     *   <li>datos[5] → usuario</li>
     *   <li>datos[6] → password</li>
     *   <li>datos[7] → rol</li>
     * </ul>
     * 
     * @param datos Array de strings con los campos del usuario extraídos del archivo.
     *              Debe tener al menos 8 elementos.
     * @return Nuevo objeto Usuario con las credenciales y rol asignados.
     * @throws ArrayIndexOutOfBoundsException Si el array tiene menos de 8 elementos.
     */
   private Usuario crearUsuario(String[] datos) {
    Usuario u = new Usuario();
    u.setUsuario(datos[5].trim());
    u.setPassword(datos[6].trim());
    u.setRol(datos[7].trim());
    return u;
}

}
