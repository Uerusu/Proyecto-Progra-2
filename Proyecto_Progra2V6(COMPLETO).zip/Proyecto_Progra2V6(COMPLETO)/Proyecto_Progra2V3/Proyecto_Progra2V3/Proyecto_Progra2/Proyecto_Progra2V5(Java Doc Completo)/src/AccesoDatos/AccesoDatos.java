package AccesoDatos;

/**
     * Clase responsable de la gestión de acceso a datos mediante archivos de
     * texto plano. Proporciona operaciones CRUD (Crear, Leer, Actualizar,
     * Eliminar) para la persistencia de datos del sistema de nómina. Utiliza el
     * formato CSV para almacenar información.
     *
     * <p>
     * Esta clase implementa el patrón DAO (Data Access Object) simplificado,
     * manejando la lectura y escritura de registros en archivos .txt.</p>
     *
     * @author Saul
     * @version 1.0.2
     * @since 1.0.0
     */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccesoDatos {
    /**
     * Nombre del archivo por defecto para almacenar información de empleados.
     * Constante que define la ubicación del archivo de persistencia.
     */
    
    private static final String EMPLEADOS = "empleados.txt";
    /**
     * Registro actual en formato CSV que será procesado (agregado o modificado).
     * Contiene una línea completa de datos separados por comas.
     */
    private String registro;
     /**
     * Nombre del archivo sobre el cual se realizarán las operaciones de lectura/escritura.
     * Permite trabajar con diferentes archivos de datos según la necesidad.
     */
    private String nombreArchivo;
    /**
     * Lista que almacena todos los registros leídos del archivo.
     * Cada elemento es un array de strings representando los campos de un registro.
     */
    private ArrayList<String[]> listaRegistros;
    /**
     * Identificador único del registro que será modificado o eliminado.
     * Utilizado como clave de búsqueda en operaciones de actualización.
     */
    private int idRegistro;
    /**
     * Bandera que indica si la operación de modificación debe eliminar el registro.
     * true = eliminar, false = actualizar.
     */
    private boolean eliminar;
    /**
     * Constructor por defecto de la clase AccesoDatos.
     * Inicializa la lista de registros como un ArrayList vacío, preparado
     * para almacenar los datos que se lean de los archivos.
     * 
     * @see ArrayList
     */
    public AccesoDatos() {

        listaRegistros = new ArrayList<>();
    }

    public String getRegistro() {
        return registro;
    }

    public void setRegistro(String registro) {
        this.registro = registro;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public ArrayList<String[]> getListaRegistros() {
        return listaRegistros;
    }

    public void setListaRegistros(ArrayList<String[]> listaRegistros) {
        this.listaRegistros = listaRegistros;
    }

    public int getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(int idRegistro) {
        this.idRegistro = idRegistro;
    }

    public boolean isEliminar() {
        return eliminar;
    }

    public void setEliminar(boolean eliminar) {
        this.eliminar = eliminar;
    }
    /**
     * Agrega un nuevo registro al final del archivo especificado.
     * El registro debe estar previamente configurado mediante setRegistro().
     * 
     * <p>Operación de tipo CREATE en el patrón CRUD. Añade una nueva línea
     * al archivo sin modificar los registros existentes.</p>
     * 
     * <p><b>Prerrequisitos:</b></p>
     * <ul>
     *   <li>nombreArchivo debe estar configurado</li>
     *   <li>registro debe contener datos válidos en formato CSV</li>
     * </ul>
     * 
     * @throws IOException Si ocurre un error al acceder o escribir en el archivo.
     *                     Posibles causas: archivo bloqueado, sin permisos,
     *                     espacio en disco insuficiente.
     * @see #setRegistro(String)
     * @see #setNombreArchivo(String)
     */

    public void agregarRegistro() throws IOException {

        try (BufferedWriter bW = new BufferedWriter(new FileWriter(this.nombreArchivo, true))) {

            bW.append(this.registro);
            bW.newLine();

        }

    }
    /**
     * Lee todos los registros del archivo y los carga en la lista interna.
     * Cada línea del archivo se convierte en un array de strings dividido por comas.
     * 
     * <p>Operación de tipo READ en el patrón CRUD. Carga todos los datos
     * del archivo en memoria para su procesamiento.</p>
     * 
     * <p><b>Nota:</b> Este método limpia la lista existente y la recarga
     * completamente con los datos del archivo.</p>
     * 
     * @throws IOException Si el archivo no existe, no se puede leer o está corrupto.
     * @see #getListaRegistros()
     * @see #setNombreArchivo(String)
     */

    public void listarRegistros() throws IOException {

        try (BufferedReader bR = new BufferedReader(new FileReader(this.nombreArchivo))) {

            String linea;

            while ((linea = bR.readLine()) != null) {

                String[] datos = linea.split(",");

                this.listaRegistros.add(datos);

            }

        }

    }
    /**
     * Actualiza la información de un empleado específico en el archivo.
     * Busca el empleado por ID y modifica su nombre completo y email,
     * manteniendo el resto de los datos intactos.
     * 
     * <p>Este método es específico para la entidad Empleado y asume
     * un formato de 5 campos: id, nombreCompleto, email, salario, rol.</p>
     * 
     * @param id Identificador único del empleado a actualizar.
     * @param nombreCompleto Nuevo nombre completo del empleado.
     *                       Puede incluir nombre y apellidos separados por espacios.
     * @param email Nueva dirección de correo electrónico del empleado.
     *              Debe ser una dirección válida.
     * @throws IOException Si ocurre un error al leer o escribir el archivo.
     * @throws NumberFormatException Si el ID en el archivo no es un número válido.
     */
    
    public void actualizarEmpleado(int id, String nombreCompleto, String email) throws IOException {
    List<String> lineas = new ArrayList<>();
    boolean encontrado = false;
    
    // Leer todas las líneas
    try (BufferedReader br = new BufferedReader(new FileReader(EMPLEADOS))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(",");
            
            // Si encontramos el ID, actualizamos nombre y email
            if (datos[0].equals(String.valueOf(id))) {
                // Mantener: id, nombre actualizado, email actualizado, salario, rol
                linea = datos[0] + "," + nombreCompleto + "," + email + "," + 
                       datos[3] + "," + datos[4];
                encontrado = true;
            }
            lineas.add(linea);
        }
    }
    
    // Escribir todo de vuelta
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(EMPLEADOS))) {
        for (String linea : lineas) {
            bw.write(linea);
            bw.newLine();
        }
    }
}
    /**
     * Modifica o elimina un registro específico del archivo.
     * La operación depende del valor de la bandera 'eliminar':
     * - Si eliminar = true: elimina el registro
     * - Si eliminar = false: actualiza el registro con los nuevos datos
     * 
     * <p>Operación de tipo UPDATE/DELETE en el patrón CRUD. Utiliza un archivo
     * temporal para evitar corrupción de datos durante la modificación.</p>
     * 
     * <p><b>Proceso:</b></p>
     * <ol>
     *   <li>Crea un archivo temporal</li>
     *   <li>Copia todos los registros excepto el que se modifica/elimina</li>
     *   <li>Si es actualización, escribe el registro modificado</li>
     *   <li>Elimina el archivo original</li>
     *   <li>Renombra el temporal al nombre original</li>
     * </ol>
     * 
     * <p><b>Prerrequisitos:</b></p>
     * <ul>
     *   <li>idRegistro debe estar configurado</li>
     *   <li>eliminar debe estar configurado</li>
     *   <li>Si es actualización, registro debe contener los nuevos datos</li>
     * </ul>
     * 
     * @throws IOException Si ocurre error al leer/escribir archivos, eliminar
     *                     el original o renombrar el temporal.
     * @see #setIdRegistro(int)
     * @see #setEliminar(boolean)
     * @see #setRegistro(String)
     */

    public void modificarRegistro() throws IOException {
        
        File archivoOriginal = new File(this.nombreArchivo);
        File archivoTemp = new File("temp_" + this.nombreArchivo);
        

        try (BufferedReader bR = new BufferedReader(new FileReader(archivoOriginal));
                BufferedWriter bW = new BufferedWriter(new FileWriter(archivoTemp))) {

            String linea;

            while ((linea = bR.readLine()) != null) {

                String[] datos = linea.split(",");

                if (this.idRegistro == Integer.parseInt(datos[0])) {

                    if (this.eliminar) {

                        continue;

                    } else {

                        bW.append(this.registro);
                        bW.newLine();

                    }

                } else {
                    bW.append(linea);
                    bW.newLine();
                }

            }
            
        }
        
         if (!archivoOriginal.delete()){
                throw new IOException("No se puede eliminar");
            }
            
            if (!archivoTemp.renameTo(archivoOriginal)){
                throw new IOException("No se puede renombrar el archivo");
            }

    }
    /**
     * Busca y devuelve un registro completo basándose en su ID.
     * Realiza una búsqueda secuencial en el archivo especificado.
     *
     * @param id Identificador único del registro a buscar.
     * @param nombreArchivo Nombre del archivo donde se realizará la búsqueda.
     *                      Debe incluir la extensión del archivo.
     * @return String con el registro completo en formato CSV, o null si no se encuentra.
     * @throws IOException Si el archivo no existe o no se puede leer.
     * @throws NumberFormatException Si el ID en el archivo no puede convertirse a entero.
     */
    public String buscarRegistroPorId(int id, String nombreArchivo) throws IOException {
    try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
        String linea;
        String idBuscado = String.valueOf(id);

        while ((linea = br.readLine()) != null) {
            // Asumiendo que el ID es siempre el primer campo, seguido de una coma.
            if (linea.startsWith(idBuscado + ",")) {
                return linea; // Se encontró el registro completo
            }
        }
    }
    return null; // No se encontró el registro con ese ID
    }
}