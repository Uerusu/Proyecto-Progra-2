
package Entidades;

/**
 * Entidad que representa un empleado en el sistema de gestión de nómina.
 * Almacena toda la información personal, de contacto y laboral necesaria
 * para el cálculo de planillas y gestión de recursos humanos.
 * 
 * <p>Esta clase es fundamental para el sistema ya que contiene los datos base
 * sobre los cuales se calculan salarios, deducciones y aportes patronales.</p>
 * 
 * <p><b>Información gestionada:</b></p>
 * <ul>
 *   <li>Datos de identificación (ID, cédula, nombre completo)</li>
 *   <li>Información de contacto (email, teléfono)</li>
 *   <li>Datos laborales (puesto, salario bruto, tipo de planilla)</li>
 * </ul>
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 */
import java.util.ArrayList;


public class empleado {
    
    private int id;
    private String cedula;
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String email;
    private String telefono;
    private double salarioBruto;
    private String tipoPlanilla;
    private String puesto;
    private ArrayList<empleado> listaEmpleados;
    /**
     * Constructor completo que inicializa un empleado con todos sus datos.
     * Utilizado al cargar empleados desde archivos o bases de datos.
     * 
     * @param id Identificador único del empleado.
     * @param cedula Número de cédula de identidad.
     * @param nombre Primer nombre.
     * @param apellido1 Primer apellido.
     * @param apellido2 Segundo apellido.
     * @param email Correo electrónico de contacto.
     * @param telefono Número telefónico.
     * @param salarioBruto Salario mensual bruto en colones.
     * @param tipoPlanilla Tipo de planilla ("Quincenal" o "Mensual").
     * @param puesto Cargo o puesto laboral.
     */
    
    public empleado(int id, String cedula, String nombre, String apellido1, 
                    String apellido2, String email, String telefono, 
                    double salarioBruto, String tipoPlanilla, String puesto) {
        this.id = id;
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.email = email;
        this.telefono = telefono;
        this.salarioBruto = salarioBruto;
        this.tipoPlanilla = tipoPlanilla;
        this.puesto = puesto;
    }
    /**
     * Constructor por defecto que inicializa la lista de empleados.
     * Utilizado cuando se necesita crear un empleado vacío para
     * posteriormente asignar sus valores mediante setters.
     */
    public empleado() {
        listaEmpleados = new ArrayList<>();
    }
    
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public String getApellido1() { return apellido1; }
    public void setApellido1(String apellido1) { this.apellido1 = apellido1; }
    
    public String getApellido2() { return apellido2; }
    public void setApellido2(String apellido2) { this.apellido2 = apellido2; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    
    public double getSalarioBruto() { return salarioBruto; }
    public void setSalarioBruto(double salarioBruto) { this.salarioBruto = salarioBruto; }
    
    public String getTipoPlanilla() { return tipoPlanilla; }
    public void setTipoPlanilla(String tipoPlanilla) { this.tipoPlanilla = tipoPlanilla; }
    
    public String getPuesto() { return puesto; }
    public void setPuesto(String puesto) { this.puesto = puesto; }
    
    public ArrayList<empleado> getListaEmpleados() { return listaEmpleados; }
    public void setListaEmpleados(ArrayList<empleado> listaEmpleados) { 
        this.listaEmpleados = listaEmpleados; 
    }
    
    public void agregarListaEmpleados(empleado empleado) {
        this.listaEmpleados.add(empleado);
    }
    
    public String getNombreCompleto() {
        return nombre + " " + apellido1 + " " + apellido2;
    }
}