
package Entidades;
/**
 * Entidad que representa una planilla para un empleado específico.
 * Contiene todos los cálculos financieros relacionados con el salario, deducciones de ley,
 * aportes patronales y el salario neto resultante.
 * 
 * <p>Esta clase es el núcleo del sistema de nómina, integra la información
 * del empleado con todos los cálculos financieros y legales requeridos para generar
 * un comprobante de pago completo y conforme a la legislación costarricense.</p>
 * 
 * <p><b>Componentes principales:</b></p>
 * <ul>
 *   <li>Deducciones del empleado: CCSS (IVM + SEM), Banco Popular, Impuesto sobre la Renta</li>
 *   <li>Aportes patronales: CCSS, INA, FCL, Asignaciones Familiares</li>
 *   <li>Información del período y fecha de emisión</li>
 *   <li>Cálculo de salario neto</li>
 * </ul>
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 * @see empleado
 * @see LogicaNegocio.Deducciones
 */
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
public class Planilla {
    
    private int id;
    private empleado empleado;
    private LocalDate fechaEmision;
    private String periodo;
    
    private double salarioBruto;
    private double salarioNeto;
    
     /**
     * Deducción total por concepto de Caja Costarricense de Seguro Social (CCSS).
     * 10.67% del salario bruto.
     */
    private double deduccionCCSS;
    /**
     * Deducción por Invalidez, Vejez y Muerte (IVM).
     * 4.17% del salario bruto.
     */
    private double deduccionIVM;
    /**
     * Deducción por Seguro de Enfermedad y Maternidad (SEM).
     * 6.50% del salario bruto (anteriormente 5.50%).
     */
    private double deduccionSEM;
    /**
     * Deducción por concepto de ahorro en el Banco Popular.
     * 1% del salario bruto.
     */
    private double deduccionBancoPop;
     /**
     * Deducción por Impuesto sobre la Renta.
     * Calculado por tramos según la legislación tributaria vigente.
     * Solo aplica si el salario supera la base libre de ₡941,000.
     */
    private double deduccionImpuestoRenta;
    
    // Aportes patronales
    private double aporteCCSS;
    /**
     * Aporte patronal por Invalidez, Vejez y Muerte (IVM).
     * 7.08% del salario bruto.
     */
    private double aporteIVM;
     /**
     * Aporte patronal por Seguro de Enfermedad y Maternidad (SEM).
     * 10.59% del salario bruto .
     */
    private double aporteSEM;
     /**
     * Aporte patronal al Instituto Nacional de Aprendizaje (INA).
     * 1.5% del salario bruto.
     */
    private double aporteINA;
     /**
     * Aporte patronal al Fondo de Capitalización Laboral (FCL).
     * 3% del salario bruto.
     */
    private double aporteFCL;
     /**
     * Aporte patronal para Asignaciones Familiares (IMAS).
     * 5% del salario bruto.
     */
    private double aporteAsignaciones;
    /**
     * Constructor completo para crear una planilla con datos iniciales.
     * Establece automáticamente la fecha de emisión al momento actual
     * y copia el salario bruto del empleado.
     * 
     * <p><b>Nota:</b> Los cálculos de deducciones y aportes deben realizarse
     * posteriormente mediante la clase Deducciones.</p>
     * 
     * @param id Identificador único de la planilla.
     * @param empleado Objeto empleado con toda su información.
     * @param periodo Descripción del período de pago .
     * @see LogicaNegocio.Deducciones#calcularNominaCompleta(Planilla)
     */
    public Planilla(int id, empleado empleado, String periodo) {
        this.id = id;
        this.empleado = empleado;
        this.periodo = periodo;
        this.fechaEmision = LocalDate.now();
        this.salarioBruto = empleado.getSalarioBruto();
    }
    
    public Planilla() {}
    
    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public empleado getEmpleado() { return empleado; }
    public void setEmpleado(empleado empleado) { this.empleado = empleado; }
    
    public LocalDate getFechaEmision() { return fechaEmision; }
    public void setFechaEmision(LocalDate fechaEmision) { this.fechaEmision = fechaEmision; }
    
    public String getPeriodo() { return periodo; }
    public void setPeriodo(String periodo) { this.periodo = periodo; }
    
    public double getSalarioBruto() { return salarioBruto; }
    public void setSalarioBruto(double salarioBruto) { this.salarioBruto = salarioBruto; }
    
    public double getSalarioNeto() { return salarioNeto; }
    public void setSalarioNeto(double salarioNeto) { this.salarioNeto = salarioNeto; }
    
    public double getDeduccionCCSS() { return deduccionCCSS; }
    public void setDeduccionCCSS(double deduccionCCSS) { this.deduccionCCSS = deduccionCCSS; }
    
    public double getDeduccionIVM() { return deduccionIVM; }
    public void setDeduccionIVM(double deduccionIVM) { this.deduccionIVM = deduccionIVM; }
    
    public double getDeduccionSEM() { return deduccionSEM; }
    public void setDeduccionSEM(double deduccionSEM) { this.deduccionSEM = deduccionSEM; }
    
    public double getDeduccionBancoPop() { return deduccionBancoPop; }
    public void setDeduccionBancoPop(double deduccionBancoPop) { 
        this.deduccionBancoPop = deduccionBancoPop; 
    }
    
    public double getDeduccionImpuestoRenta() { return deduccionImpuestoRenta; }
    public void setDeduccionImpuestoRenta(double deduccionImpuestoRenta) { 
        this.deduccionImpuestoRenta = deduccionImpuestoRenta; 
    }
    
    public double getAporteCCSS() { return aporteCCSS; }
    public void setAporteCCSS(double aporteCCSS) { this.aporteCCSS = aporteCCSS; }
    
    public double getAporteIVM() { return aporteIVM; }
    public void setAporteIVM(double aporteIVM) { this.aporteIVM = aporteIVM; }
    
    public double getAporteSEM() { return aporteSEM; }
    public void setAporteSEM(double aporteSEM) { this.aporteSEM = aporteSEM; }
    
    public double getAporteINA() { return aporteINA; }
    public void setAporteINA(double aporteINA) { this.aporteINA = aporteINA; }
    
    public double getAporteFCL() { return aporteFCL; }
    public void setAporteFCL(double aporteFCL) { this.aporteFCL = aporteFCL; }
    
    public double getAporteAsignaciones() { return aporteAsignaciones; }
    public void setAporteAsignaciones(double aporteAsignaciones) { 
        this.aporteAsignaciones = aporteAsignaciones; 
    }
    
    public double getTotalDeducciones() {
        return deduccionCCSS + deduccionBancoPop + deduccionImpuestoRenta;
    }
    
    public double getTotalAportesPatronales() {
        return aporteCCSS + aporteINA + aporteFCL + aporteAsignaciones;
    }
    
    /**
     * Obtiene la fecha de emisión formateada en español.
     * Convierte la fecha al formato "dd 'de' MMMM 'de' yyyy" en español.
     * 
     * <p><b>Ejemplo:</b> "15 de enero de 2024"</p>
     * 
     * @return String con la fecha formateada en español.
     * @see DateTimeFormatter
     */
    
    public String getFechaEmisionFormateada() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return fechaEmision.format(formatter);
        
        
    }
}


