package Entidades;
/**
 * Entidad que representa un usuario del sistema de nómina.
 * Permite el control de acceso basado en permisos según el nivel de autorización.
 * 
 * <p>Los usuarios pueden tener tres roles principales:</p>
 * <ul>
 *   <li><b>Administrador:</b> Acceso completo al sistema</li>
 *   <li><b>Patrono:</b> Gestión de planillas y reportes</li>
 *   <li><b>Empleado:</b> Consulta de información personal limitada</li>
 * </ul>
 * 
 * <p>Esta clase sirve como base para Correo (herencia) y es utilizada
 * extensamente en el módulo de autenticación y autorización.</p>
 * 
 * @author Saul
 * @version 1.0.0
 * @since 1.0.0
 * @see Correo
 * @see LogicaNegocio.AutenticacionBL
 */
import java.util.ArrayList;


public class Usuario {

    private int id;
    private String nombre, apellido1, apellido2, email, usuario, password, rol;
    private ArrayList<Usuario> listaUsuarios;
    
     /**
     * Constructor completo que inicializa un usuario con todos sus datos.
     * Utilizado al cargar usuarios desde archivos o al crear nuevos registros.
     * 
     * @param id Identificador único del usuario.
     * @param nombre Primer nombre.
     * @param apellido1 Primer apellido.
     * @param apellido2 Segundo apellido.
     * @param email Correo electrónico de contacto y notificaciones.
     * @param usuario Nombre de usuario único para login.
     * @param password Contraseña (idealmente hasheada en producción).
     * @param rol Nivel de acceso: "Administrador", "Patrono" o "Empleado".
     */
   public Usuario(int id, String nombre, String apellido1, String apellido2,
               String email, String usuario, String password, String rol) {
    this.id = id;
    this.nombre = nombre;
    this.apellido1 = apellido1;
    this.apellido2 = apellido2;
    this.email = email;
    this.usuario = usuario;
    this.password = password;
    this.rol = rol;
}
     /**
     * Constructor por defecto que inicializa la lista de usuarios.
     * Permite crear un usuario vacío para posteriormente asignar valores.
     */

    public Usuario() {
        listaUsuarios = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }
    
    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public ArrayList<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(ArrayList<Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }

    public void agregarListaUsuarios(Usuario usuario) {
        this.listaUsuarios.add(usuario);
    }

}