
package Entidades;

/**
 * Entidad que representa un correo electrónico en el sistema de nómina.
 * Extiende de Usuario para heredar información del remitente y gestiona
 * el contenido del correo y sus archivos adjuntos.
 * 
 * <p>Esta clase se utiliza principalmente para el envío de comprobantes de pago,
 * notificaciones y comunicaciones oficiales a empleados.</p>
 * 
 * <p><b>Características principales:</b></p>
 * <ul>
 *   <li>Gestión de asunto y mensaje del correo</li>
 *   <li>Soporte para múltiples archivos adjuntos</li>
 *   <li>Herencia de datos del usuario remitente</li>
 * </ul>
 * 
 * @author Saul
 * @version 1.0.0
 * @since 1.0.0
 * @see Usuario
 */


import java.io.File;
import java.util.ArrayList;

public class Correo extends Usuario{ //Herencia de Usuario
    /**
     * Contenido textual del mensaje del correo.
     * Puede contener texto plano o HTML dependiendo de la configuración del servidor SMTP.
     */
    private String mensaje;
    /**
     * Asunto o título del correo electrónico.
     * Debe ser descriptivo para que el destinatario identifique el propósito del correo.
     */
    private String asunto;
    /**
     * Lista de archivos que se adjuntarán al correo.
     * Comúnmente incluye PDFs de comprobantes de pago, reportes y documentos oficiales.
     */
    private ArrayList<File> archivosAdjuntos;
     /**
     * Constructor por defecto de la clase Correo.
     * Inicializa la lista de archivos adjuntos como un ArrayList vacío.
     * Hereda el constructor de la clase Usuario.
     */

    public Correo(){
        
        this.archivosAdjuntos = new ArrayList<>();
        
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getAsunto() {
        return asunto;
    }

    public void setAsunto(String asunto) {
        this.asunto = asunto;
    }

    public ArrayList<File> getArchivos() {
        return archivosAdjuntos;
    }

    public void setArchivos(ArrayList<File> Archivos) {
        this.archivosAdjuntos = Archivos;
    }
    
     /**
     * Agrega un archivo individual a la lista de adjuntos del correo.
     * Permite construir la lista de adjuntos de forma incremental.
     * 
     * @param archivoAdjunto Objeto File que representa el archivo a adjuntar.
     *                       El archivo debe existir en el sistema de archivos
     *                       antes de enviarse el correo.
     * @see File
     */
    public void agregarArchivoAdjunto(File archivoAdjunto){ 
        this.archivosAdjuntos.add(archivoAdjunto);
    }

    public ArrayList<File> getArchivosAdjuntos() {
        return archivosAdjuntos;
    }

    public void setArchivosAdjuntos(ArrayList<File> archivosAdjuntos) {
        this.archivosAdjuntos = archivosAdjuntos;
    }
    
}