package Utilidades;
/**
 * Clase de utilidades para manipulación de tablas JTable en Swing.
 * 
 * <p><b>IMPORTANTE:</b> Esta clase no debe modificarse una vez en producción,
 * ya que es utilizada por múltiples formularios del sistema.</p>
 * 
 * <p><b>Funcionalidades principales:</b></p>
 * <ul>
 *   <li>Auto-ajuste de ancho de columnas según contenido</li>
 *   <li>Configuración de tablas no editables</li>
 *   <li>Carga de datos desde listas a modelos de tabla</li>
 *   <li>Configuración de selección de filas</li>
 * </ul>
 * 
 * @author Saul
 * @version 1.0.0
 * @since 1.0.0
 */

import java.util.List;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

public class UtilidadesTablas {
     /**
     * Ajusta automáticamente el ancho de las columnas según su contenido.
     * Calcula el ancho necesario para cada columna basándose en el contenido
     * de todas las filas, incluyendo un margen adicional.
     * 
     * @param tabla JTable a la cual se ajustarán las columnas.
     *              La tabla debe tener datos cargados.
     */
    public static void autoAjustarColumnas(JTable tabla) {
        for (int col = 0; col < tabla.getColumnCount(); col++) {
            int anchoMaximo = 0;
            for (int fila = 0; fila < tabla.getRowCount(); fila++) {
                var renderer = tabla.getCellRenderer(fila, col);
                var componente = tabla.prepareRenderer(renderer, fila, col);
                anchoMaximo = Math.max(componente.getPreferredSize().width, anchoMaximo);
            }
            tabla.getColumnModel().getColumn(col).setPreferredWidth(anchoMaximo + 10);
        }
    }
    /**
     * Configura una tabla con datos y establece propiedades estándar.
     * Crea un modelo de tabla no editable, carga los datos proporcionados
     * y configura la selección a nivel de fila completa.
     * 
     * <p><b>Configuraciones aplicadas:</b></p>
     * <ul>
     *   <li>Modelo no editable (isCellEditable retorna false)</li>
     *   <li>Selección de una sola fila a la vez</li>
     *   <li>Selección solo de filas completas (no celdas individuales)</li>
     *   <li>Auto-ajuste de columnas según contenido</li>
     * </ul>
     * 
     * @param tabla JTable a configurar. Debe estar inicializada.
     * @param columnas Array de strings con los nombres de las columnas.
     *                 Define los encabezados de la tabla.
     * @param datos Lista de arrays de strings. Cada array representa una fila,
     *              y cada elemento del array una celda. El número de elementos
     *              debe coincidir con el número de columnas.
     * @see #autoAjustarColumnas(JTable)
     */

    public static void configurarTablaConDatos(JTable tabla, String[] columnas, List<String[]> datos) {
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // No editable
            }
        };

        for (String[] fila : datos) {
            modelo.addRow(fila);
        }

        tabla.setModel(modelo);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setCellSelectionEnabled(false);
        tabla.setRowSelectionAllowed(true);
        tabla.setColumnSelectionAllowed(false);
        autoAjustarColumnas(tabla);
    }
}
