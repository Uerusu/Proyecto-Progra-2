package Utilidades;
/**
 * Enumeración que centraliza los nombres de archivos de persistencia.
 * Define constantes tipo-seguras para todos los archivos de datos del sistema,
 * evitando errores de escritura y facilitando el mantenimiento.
 * 
 * <p><b>Archivos definidos:</b></p>
 * <ul>
 *   <li><b>ID_CONTROL:</b> "IdControl.txt" - Contadores de IDs por archivo</li>
 *   <li><b>USUARIOS:</b> "usuarios.txt" - Datos de usuarios del sistema</li>
 *   <li><b>EMPLEADOS:</b> "empleados.txt" - Registro de empleados</li>
 * </ul>
 * @author Saul
 * @version 1.0.0
 * @since 1.0.0
 */

public enum NombresArchivos {
    ID_CONTROL("IdControl.txt"),
    USUARIOS("usuarios.txt"),
    EMPLEADOS("empleados.txt");

    private final String nombreArchivo;

    NombresArchivos(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

}
