
package Utilidades;
/**
 * Clase de constantes para el sistema de nómina.
 * 
 * <p><b>Categorías de constantes:</b></p>
 * 
 * <p><b>1. Configuración de Correo:</b></p>
 * <ul>
 *   <li>SMTP_HOST: Servidor de correo saliente</li>
 *   <li>SMTP_PORT: Puerto SSL (465)</li>
 *   <li>EMAIL_FROM: Cuenta remitente del sistema</li>
 *   <li>EMAIL_PASSWORD: Contraseña de autenticación SMTP</li>
 * </ul>
 * 
 * <p><b>2. Tipos de Planilla:</b></p>
 * <ul>
 *   <li>PLANILLA_QUINCENAL: "QUINCENAL"</li>
 *   <li>PLANILLA_MENSUAL: "MENSUAL"</li>
 * </ul>
 * 
 * <p><b>3. Deducciones del Empleado:</b></p>
 * <ul>
 *   <li>DEDUCCION_IVM: 0.0417 (4.17% - Invalidez, Vejez y Muerte)</li>
 *   <li>DEDUCCION_SEM: 0.0650 (6.50% - Seguro de Enfermedad y Maternidad)</li>
 *   <li>DEDUCCION_CCSS: 0.1067 (10.67% - Total CCSS)</li>
 *   <li>DEDUCCION_BANCO_POPULAR: 0.01 (1% - Ahorro obligatorio)</li>
 * </ul>
 * 
 * <p><b>4. Aportes Patronales:</b></p>
 * <ul>
 *   <li>APORTE_IVM: 0.0708 (7.08%)</li>
 *   <li>APORTE_SEM: 0.1059 (10.59%)</li>
 *   <li>APORTE_CCSS: 0.2667 (26.67% - Total CCSS patronal)</li>
 *   <li>APORTE_INA: 0.015 (1.5% - Instituto Nacional de Aprendizaje)</li>
 *   <li>APORTE_FCL: 0.03 (3% - Fondo de Capitalización Laboral)</li>
 *   <li>APORTE_ASIGNACIONES: 0.05 (5% - Asignaciones Familiares / IMAS)</li>
 * </ul>
 * 
 * <p><b>5. Tramos de Impuesto sobre la Renta (2024):</b></p>
 * <ul>
 *   <li>RENTA_BASE_LIBRE: ₡941,000 (exento de impuesto)</li>
 *   <li>RENTA_TRAMO1_LIMITE: ₡1,405,000 (hasta aquí 10%)</li>
 *   <li>RENTA_TRAMO1_PORCENTAJE: 0.10</li>
 *   <li>RENTA_TRAMO2_LIMITE: ₡2,108,000 (hasta aquí 15%)</li>
 *   <li>RENTA_TRAMO2_PORCENTAJE: 0.15</li>
 *   <li>RENTA_TRAMO3_LIMITE: ₡4,215,000 (hasta aquí 20%)</li>
 *   <li>RENTA_TRAMO3_PORCENTAJE: 0.20</li>
 *   <li>RENTA_TRAMO4_PORCENTAJE: 0.25 (más de ₡4,215,000)</li>
 * </ul>
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 */
public class montos {
    // Configuración de correo
    public static final String SMTP_HOST = "securemail.comredcr.com";
    public static final String SMTP_PORT = "465";
    public static final String EMAIL_FROM = "curso_progra2@comredcr.com";
    public static final String EMAIL_PASSWORD = "u6X1h1p9@";
    
    // Tipos de planilla
    public static final String PLANILLA_QUINCENAL = "QUINCENAL";
    public static final String PLANILLA_MENSUAL = "MENSUAL";
    
    // Deducciones del empleado
    public static final double DEDUCCION_CCSS = 0.1067;
    public static final double DEDUCCION_IVM = 0.0417;
    public static final double DEDUCCION_SEM = 0.0650;
    public static final double DEDUCCION_BANCO_POPULAR = 0.01;
    
    // Aportes patronales
    public static final double APORTE_CCSS = 0.2667;
    public static final double APORTE_IVM = 0.0708;
    public static final double APORTE_SEM = 0.1059;
    public static final double APORTE_INA = 0.015;
    public static final double APORTE_FCL = 0.03;
    public static final double APORTE_ASIGNACIONES = 0.05;
    
    // Tramos de impuesto sobre la renta 2024
    public static final double RENTA_BASE_LIBRE = 941000;
    public static final double RENTA_TRAMO1_LIMITE = 1405000;
    public static final double RENTA_TRAMO1_PORCENTAJE = 0.10;
    public static final double RENTA_TRAMO2_LIMITE = 2108000;
    public static final double RENTA_TRAMO2_PORCENTAJE = 0.15;
    public static final double RENTA_TRAMO3_LIMITE = 4215000;
    public static final double RENTA_TRAMO3_PORCENTAJE = 0.20;
    public static final double RENTA_TRAMO4_PORCENTAJE = 0.25;
    
    
    
    private montos() {}
}


