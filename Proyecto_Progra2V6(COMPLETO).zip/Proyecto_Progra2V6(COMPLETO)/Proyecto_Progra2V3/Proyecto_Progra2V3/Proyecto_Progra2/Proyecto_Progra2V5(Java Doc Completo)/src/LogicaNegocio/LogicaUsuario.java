
package LogicaNegocio;
/**
 * Clase de lógica de negocio para la administración completa de usuarios del sistema.
 * 
 * <p>Esta clase es responsable de:</p>
 * <ul>
 *   <li>Gestionar el ciclo de vida completo de usuarios</li>
 *   <li>Asegurar IDs únicos mediante IdControl</li>
 *   <li>Mantener integridad de datos en operaciones de modificación</li>
 *   <li>Proporcionar búsqueda y listado de usuarios</li>
 * </ul>
 * 
 * @author Saul
 * @version 1.0.0
 * @since 1.0.0
 * @see AccesoDatos.AccesoDatos
 * @see AccesoDatos.IdControl
 * @see Entidades.Usuario
 */
import AccesoDatos.AccesoDatos;
import AccesoDatos.IdControl;
import Entidades.Usuario;
import Utilidades.NombresArchivos;
import java.io.IOException;


public class LogicaUsuario {

    private AccesoDatos accesoDatos;
    private IdControl idControl;
     /**
     * Agrega un nuevo usuario al sistema asignándole un ID único.
     * El usuario se persiste en el archivo de usuarios con todos sus datos.
     * 
     * <p><b>Proceso de creación:</b></p>
     * <ol>
     *   <li>Inicializa AccesoDatos e IdControl</li>
     *   <li>Configura el archivo destino (usuarios.txt)</li>
     *   <li>Solicita nuevo ID único a IdControl</li>
     *   <li>Asigna el ID al objeto usuario</li>
     *   <li>Construye registro CSV con 8 campos</li>
     *   <li>Guarda el registro en el archivo</li>
     * </ol>
     * 
     * <p><b>Registro generado:</b></p>
     * <pre>
     * id,nombre,apellido1,apellido2,email,usuario,password,rol
     * </pre>
     * 
     * @param usuario Objeto Usuario con todos los datos completos EXCEPTO el ID.
     *                El ID será asignado automáticamente por este método.
     *                Campos requeridos: nombre, apellido1, apellido2, email,
     *                usuario, password, rol.
     * @throws IOException Si ocurre error al:
     *         <ul>
     *           <li>Acceder al archivo de control de IDs</li>
     *           <li>Escribir en el archivo de usuarios</li>
     *           <li>Actualizar el contador de IDs</li>
     *         </ul>
     * @see IdControl#getNextId(String)
     * @see AccesoDatos#agregarRegistro()
     */

    public void agregarUsuario(Usuario usuario) throws IOException {

    accesoDatos = new AccesoDatos();
    idControl = new IdControl();
    accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());

    usuario.setId(idControl.getNextId(NombresArchivos.USUARIOS.getNombreArchivo()));


    // 🔹 Guardar el registro completo (8 campos)
    accesoDatos.setRegistro(
            usuario.getId() + "," +
            usuario.getNombre() + "," +
            usuario.getApellido1() + "," +
            usuario.getApellido2() + "," +
            usuario.getEmail() + "," +
            usuario.getUsuario() + "," +
            usuario.getPassword() + "," +
            usuario.getRol()
    );

    accesoDatos.agregarRegistro();
}
     /**
     * Actualiza los datos de un usuario existente en el sistema.
     * Reemplaza el registro completo del usuario manteniendo el mismo ID.
     * 
     * <p><b>Proceso de actualización:</b></p>
     * <ol>
     *   <li>Inicializa AccesoDatos</li>
     *   <li>Configura archivo de usuarios</li>
     *   <li>Establece ID del usuario a modificar</li>
     *   <li>Construye nuevo registro con datos actualizados</li>
     *   <li>Configura modo actualización (eliminar=false)</li>
     *   <li>Ejecuta modificación (lee todo, reemplaza línea, reescribe todo)</li>
     * </ol>
     * 
     * <p><b>Campos modificables:</b> Todos excepto el ID.</p>
     * 
     * 
     * @param usuario Objeto Usuario con el ID del usuario a actualizar
     *                y todos los campos con los nuevos valores.
     *                El ID debe corresponder a un usuario existente.
     * @throws IOException Si ocurre error al leer o escribir el archivo.
     * @see AccesoDatos#modificarRegistro()
     */

    public void actualizarUsuario(Usuario usuario) throws IOException {

    accesoDatos = new AccesoDatos();
    accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());
    accesoDatos.setIdRegistro(usuario.getId());

    accesoDatos.setRegistro(
            usuario.getId() + "," +
            usuario.getNombre() + "," +
            usuario.getApellido1() + "," +
            usuario.getApellido2() + "," +
            usuario.getEmail() + "," +
            usuario.getUsuario() + "," +
            usuario.getPassword() + "," +
            usuario.getRol()        
    );

    accesoDatos.setEliminar(false);
    accesoDatos.modificarRegistro();
}
    /**
     * Elimina un usuario del sistema de forma permanente.
     * Remueve el registro del archivo de usuarios basándose en el ID.
     * 
     * <p><b>Proceso de eliminación:</b></p>
     * <ol>
     *   <li>Inicializa AccesoDatos</li>
     *   <li>Configura archivo de usuarios</li>
     *   <li>Establece ID del usuario a eliminar</li>
     *   <li>Configura modo eliminación (eliminar=true)</li>
     *   <li>Ejecuta modificación (lee todo, omite línea, reescribe resto)</li>
     * </ol>
     * 
     * @param usuario Objeto Usuario con el ID del usuario a eliminar.
     *                Solo se requiere que tenga el ID configurado.
     *                Los demás campos son ignorados.
     * @throws IOException Si ocurre error al leer o escribir el archivo.
     * @see AccesoDatos#modificarRegistro()
     */

    public void eliminarUsuario(Usuario usuario) throws IOException {
        
        accesoDatos = new AccesoDatos();
        accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());
        accesoDatos.setIdRegistro(usuario.getId());
        accesoDatos.setEliminar(true);
        accesoDatos.modificarRegistro();
        
    }
    /**
     * Lista todos los usuarios del sistema cargándolos en la lista interna
     * del objeto Usuario proporcionado.
     * 
     * <p><b>Proceso de listado:</b></p>
     * <ol>
     *   <li>Inicializa AccesoDatos</li>
     *   <li>Configura archivo de usuarios</li>
     *   <li>Lee todos los registros del archivo</li>
     *   <li>Para cada registro:
     *     <ul>
     *       <li>Divide en campos por comas</li>
     *       <li>Crea objeto Usuario con datos completos</li>
     *       <li>Agrega a lista interna del usuario parámetro</li>
     *     </ul>
     *   </li>
     * </ol>
     * 
     * @param usuario Objeto Usuario que actuará como contenedor.
     *                Su lista interna (getListaUsuarios()) será poblada
     *                con todos los usuarios del sistema.
     *                El objeto mismo no se modifica, solo su lista interna.
     * @throws IOException Si el archivo no se puede leer.
     * @throws NumberFormatException Si el ID en algún registro no es numérico.
     * @throws ArrayIndexOutOfBoundsException Si algún registro no tiene 8 campos.
     * @see Usuario#getListaUsuarios()
     * @see AccesoDatos#listarRegistros()
     */

    public void listarUsuario(Usuario usuario) throws IOException {

        accesoDatos = new AccesoDatos();
        accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());
        accesoDatos.listarRegistros();
        for(String[] datos : accesoDatos.getListaRegistros()){
            Usuario usr = new Usuario(Integer.parseInt(datos[0]), datos[1], datos[2], datos[3], datos[4], datos[5], datos[6],datos[7]);
            usuario.agregarListaUsuarios(usr);   
        }
        

    }
    
    /**
     * Obtiene un usuario completo basándose en su ID.
     * Busca el usuario en el archivo y retorna un objeto Usuario con todos sus datos.
     * 
     * <p><b>Proceso de búsqueda:</b></p>
     * <ol>
     *   <li>Llama a AccesoDatos.buscarRegistroPorId()</li>
     *   <li>Recibe línea completa del registro o null</li>
     *   <li>Si se encuentra:
     *     <ul>
     *       <li>Divide la línea en campos</li>
     *       <li>Valida que tenga al menos 8 campos</li>
     *       <li>Parsea cada campo al tipo apropiado</li>
     *       <li>Crea y retorna objeto Usuario completo</li>
     *     </ul>
     *   </li>
     *   <li>Si no se encuentra o hay error, retorna null</li>
     * </ol>
     * 
     * @param id Identificador único del usuario a buscar. Debe ser mayor que 0.
     * @return Objeto Usuario completo con todos sus datos si se encuentra,
     *         o null si:
     *         <ul>
     *           <li>El usuario no existe</li>
     *           <li>El registro está corrupto</li>
     *           <li>Hay error de formato</li>
     *         </ul>
     * @throws IOException Si hay error crítico al acceder al archivo.
     * @see AccesoDatos#buscarRegistroPorId(int, String)
     */
    public Usuario obtenerUsuarioPorId(int id) throws IOException {
    // Definimos el nombre del archivo de usuarios
    String nombreArchivoUsuarios = NombresArchivos.USUARIOS.getNombreArchivo();
    
    // Llamamos al nuevo método de AccesoDatos para obtener la línea completa
    String lineaUsuario = accesoDatos.buscarRegistroPorId(id, nombreArchivoUsuarios);

    if (lineaUsuario != null) {
        // La línea contiene: ID, Nombre, Apellido1, Apellido2, Email, Usuario, Password
        String[] datos = lineaUsuario.split(",");

        // Verificar que la línea tiene suficientes campos (al menos 7)
        if (datos.length >= 7) {
            try {
                int idUsuario = Integer.parseInt(datos[0].trim());
                String nombre = datos[1].trim();
                String apellido1 = datos[2].trim();
                String apellido2 = datos[3].trim();
                String email = datos[4].trim();
                String nombreUsuario = datos[5].trim();
                String password = datos[6].trim();
                String rol = datos[7].trim();// <-- ¡Aquí rescatamos la contraseña!

                return new Usuario(idUsuario, nombre, apellido1, apellido2, email, nombreUsuario, password, rol);
            } catch (NumberFormatException e) {
                System.err.println("Error de formato al parsear el ID del usuario: " + e.getMessage());
                return null;
            }
        } else {
            System.err.println("Error: El registro de usuario con ID " + id + " no tiene el formato correcto.");
            return null;
        }
    }
    
    return null; // Usuario no encontrado
}
    

}
