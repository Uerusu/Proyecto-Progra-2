package LogicaNegocio;

/**
 * Clase de lógica de negocio para la autenticación de usuarios.
 * Control de acceso al sistema.
 * 
 * <p>Esta clase actúa como intermediaria entre la capa de presentación y
 * la capa de acceso a datos, encapsulando la lógica de autenticación.</p>
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 * @see AccesoDatos.UsuarioDAO
 * @see Usuario
 */

import AccesoDatos.UsuarioDAO;
import Entidades.Usuario;   
import java.io.IOException;


public class AutenticacionBL {
    /**
     * Objeto DAO para acceso a datos de usuarios.
     * Utilizado para buscar y validar credenciales en el archivo de persistencia.
     */
    private UsuarioDAO usuarioDAO = new UsuarioDAO();

     /**
     * Valida si existen las credenciales proporcionadas en el sistema.
     * 
     * @param usuario Nombre de usuario a validar.
     * @param password Contraseña a validar.
     * @return true si las credenciales son válidas, false en caso contrario.
     * @throws RuntimeException Si ocurre un error al acceder al archivo de usuarios.
     *                          Encapsula IOException de la capa de datos.
     * @see #obtenerUsuario(String, String)
     */
    public boolean autenticar(String usuario, String password) {
        try {
            Usuario u = usuarioDAO.buscarPorCredenciales(usuario, password);
            return u != null;
        } catch (IOException e) {
            throw new RuntimeException("Error al acceder a usuarios: " + e.getMessage());
        }
    }

    /**
     * Obtiene el objeto Usuario completo si las credenciales son válidas.
     * A diferencia de autenticar(), este método retorna toda la información del usuario,
     * incluyendo su rol, que es esencial para determinar permisos de acceso.
     * 
     * @param usuario Nombre de usuario para autenticación.
     * @param password Contraseña para autenticación.
     * @return Objeto Usuario completo si las credenciales son válidas, null si no lo son.
     * @throws RuntimeException Si ocurre un error al acceder al archivo de usuarios.
     * @see Usuario#getRol()
     */
    public Usuario obtenerUsuario(String usuario, String password) {
        try {
            return usuarioDAO.buscarPorCredenciales(usuario, password);
        } catch (IOException e) {
            throw new RuntimeException("Error al acceder a usuarios: " + e.getMessage());
        }
    }
}
