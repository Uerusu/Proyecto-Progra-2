package LogicaNegocio;
/**
 * Clase de lógica de negocio para la generación masiva de planillas de pago.
 * 
 * <p>Esta clase actúa como orquestador del proceso de generación de nómina,
 * utilizando la clase Deducciones para realizar todos los cálculos complejos
 * de deducciones, aportes patronales y salario neto.</p>
 * 
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 * @see Entidades.Planilla
 * @see Entidades.empleado
 * @see Deducciones
 */
import Entidades.Planilla;
import Entidades.empleado;
import java.util.ArrayList;

public class LogicaPlanilla {
    /**
     * Genera planillas de pago para una lista de empleados en un período específico.
     * Crea una planilla individual para cada empleado, aplicando todos los cálculos
     * de deducciones, aportes patronales y salario neto de forma automática.
     * 
     * @param empleados Lista de empleados para los cuales generar planillas.
     *                  Cada empleado debe tener.               
     * @param periodo Descripción del período de pago. Formato libre, típicamente:
     * @return ArrayList de Planilla con todas las planillas calculadas.
     * @see Deducciones#calcularNominaCompleta(Planilla)
     * @see Planilla
     * @see empleado
     */

   public ArrayList<Planilla> generarPlanillas(ArrayList<empleado> empleados, String periodo) {

    ArrayList<Planilla> planillas = new ArrayList<>();
    Deducciones deducciones = new Deducciones();

    for (empleado emp : empleados) {

        Planilla p = new Planilla(
                emp.getId(),
                emp,
                periodo
        );

        deducciones.calcularNominaCompleta(p);
        planillas.add(p);
    }

    return planillas;
}
}