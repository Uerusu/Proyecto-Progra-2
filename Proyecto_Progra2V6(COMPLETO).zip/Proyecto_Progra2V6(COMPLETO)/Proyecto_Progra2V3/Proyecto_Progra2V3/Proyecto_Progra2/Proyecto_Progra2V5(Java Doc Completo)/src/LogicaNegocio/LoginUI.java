
package LogicaNegocio;
/**
 * Interfaz de usuario para el proceso de autenticación en el sistema de nómina.
 * Gestiona el inicio de sesión de usuarios mediante diálogos Swing, controla intentos fallidos
 * y redirige automáticamente al menú correspondiente según el rol del usuario autenticado.
 * 
 * <p>Esta clase implementa un sistema de seguridad básico con las siguientes características:</p>
 * <ul>
 *   <li>Máximo 3 intentos de autenticación antes de bloquear</li>
 *   <li>Validación de credenciales mediante AutenticacionBL</li>
 *   <li>Redirección automática según rol:
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 * @see AutenticacionBL
 * @see Presentacion.FrmMenuAdmin
 * @see Presentacion.FrmMenuPatrono
 * @see Presentacion.FrmMenuEmpleado
 */
import Entidades.Usuario;
import Presentacion.FrmMenuAdmin;
import Presentacion.FrmMenuEmpleado;
import Presentacion.FrmMenuPatrono;
import java.io.IOException;
import javax.swing.JOptionPane;

public class LoginUI {

    private AutenticacionBL service = new AutenticacionBL();
    /**
     * <p>
     * <b>Flujo del proceso de login:</b></p>
     * <ol>
     * <li>Solicitar usuario y contraseña mediante JOptionPane</li>
     * <li>Validar que no sean null (usuario canceló)</li>
     * <li>Enviar credenciales a AutenticacionBL para validación</li>
     * <li>Si es válido: obtener objeto Usuario completo con rol</li>
     * <li>Mostrar mensaje de bienvenida</li>
     * <li>Abrir ventana correspondiente según rol</li>
     * <li>Si es inválido: incrementar contador y permitir reintentar</li>
     * <li>Después de 3 intentos fallidos: bloquear acceso</li>
     * </ol>
     * 
     * <p>
     * <b>Seguridad implementada:</b></p>
     * <ul>
     * <li>Límite de 3 intentos antes de bloqueo</li>
     * <li>Contador visible de intentos restantes</li>
     * <li>Posibilidad de cancelar en cualquier momento</li>
     * <li>Validación de credenciales en capa de negocio (no en UI)</li>
     * </ul>
     *
     * @throws IOException Si hay error al acceder al archivo de usuarios
     *                     durante el proceso de autenticación o al cargar
     *                     datos del usuario. Este error detiene el login.
     * @throws InterruptedException Si el thread es interrumpido durante
     *                              la ejecución (poco común en este contexto).
     * @see #mostrarBienvenida(Usuario)
     * @see AutenticacionBL#autenticar(String, String)
     * @see AutenticacionBL#obtenerUsuario(String, String)
     */
    public void login() throws IOException, InterruptedException {

        int intentos = 0;
        boolean acceso = false;
        String usuarioIngresado = null;
        String passwordIngresado = null;

        while (intentos < 3 && !acceso) {

            usuarioIngresado = JOptionPane.showInputDialog(null, "INGRESE SU USUARIO:");
            passwordIngresado = JOptionPane.showInputDialog(null, "INGRESE SU CONTRASEÑA:");

            if (usuarioIngresado == null || passwordIngresado == null) {
                JOptionPane.showMessageDialog(null, "ACCESO CANCELADO.");
                return;
            }

            acceso = service.autenticar(usuarioIngresado.trim(), passwordIngresado.trim());

            if (!acceso) {
                intentos++;
                if (intentos < 3) {
                    JOptionPane.showMessageDialog(null,
                            "**ACCESO DENEGADO**\nIntento " + intentos + " de 3");
                }
            }
        }

        if (!acceso) {
            JOptionPane.showMessageDialog(null, "**ACCESO BLOQUEADO**");
            return;
        }

        // Obtener el Usuario completo (con rol)
        Usuario u = service.obtenerUsuario(usuarioIngresado.trim(), passwordIngresado.trim());

        if (u != null) {
            mostrarBienvenida(u);
        } else {
            JOptionPane.showMessageDialog(null, "ACCESO CONCEDIDO (sin rol)");
            // Si querés abrir FrmApp también aquí, descomenta:
            // javax.swing.SwingUtilities.invokeLater(() -> new FrmApp().setVisible(true));
        }
    }
     /**
     * Muestra mensaje de bienvenida y abre el menú correspondiente según el rol.
     * Método privado invocado automáticamente después de una autenticación exitosa.
     *
     * @param usuario Objeto Usuario con rol válido obtenido después de autenticación exitosa.
     *                El rol determina qué ventana se abrirá.
     *                No debe ser null (se valida en método llamador).
     * @throws IOException Si ocurre error al cargar recursos de los formularios.
     * @throws InterruptedException Si el thread es interrumpido durante la apertura.
     * @see Presentacion.FrmMenuAdmin
     * @see Presentacion.FrmMenuPatrono
     * @see Presentacion.FrmMenuEmpleado
     * @see java.awt.EventQueue#invokeLater(Runnable)
     */
     
    private void mostrarBienvenida(Usuario usuario) throws IOException, InterruptedException {
        // Mensaje general de bienvenida
        String rol = (usuario.getRol() == null) ? "DESCONOCIDO" : usuario.getRol();
        JOptionPane.showMessageDialog(null, "Bienvenido " + rol.toUpperCase());

        switch (rol) {
            
            case "admin":
               // MenuDeUsuarios.menuAdministrador();
                 java.awt.EventQueue.invokeLater(() -> new FrmMenuAdmin().setVisible(true));
                

                break;

            case "empleado":
                //MenuDeUsuarios.MostrarMenuEmpleado();
                java.awt.EventQueue.invokeLater(() -> new FrmMenuEmpleado().setVisible(true));
                break;


            case "patrono":
               // MenuDeUsuarios.mostrarMenuPatrono();
                java.awt.EventQueue.invokeLater(() -> new FrmMenuPatrono().setVisible(true));
                break;


            default:
                //JOptionPane.showMessageDialog(null, "OPCION INVALIDA");
                break;
        }
    }
}

    