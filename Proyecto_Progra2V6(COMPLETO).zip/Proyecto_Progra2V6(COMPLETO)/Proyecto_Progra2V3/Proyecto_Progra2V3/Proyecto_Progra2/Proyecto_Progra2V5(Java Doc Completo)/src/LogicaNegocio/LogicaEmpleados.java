package LogicaNegocio;
/**
 * Clase de lógica de negocio para la gestión de empleados.
 * 
 * <p>Esta clase actúa como intermediaria entre la capa de persistencia (archivos)
 * y la capa de presentación, transformando datos en formato texto a objetos
 * de la entidad empleado.</p>
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 * @see Entidades.empleado
 */

import Entidades.empleado;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class LogicaEmpleados {
    /**
     * Carga una lista de empleados desde un archivo de texto en formato CSV.
     * Lee el archivo línea por línea, parseando cada registro y creando objetos empleado.
     * 
     * <p><b>Formato de cada línea:</b></p>
     * <pre>id,nombreCompleto,email,salario,puesto</pre>
     * @param ruta Ruta del archivo de texto a cargar. Puede ser ruta absoluta o relativa.
     *             El archivo debe existir y tener permisos de lectura.
     *             Ejemplo: "empleados.txt" o "C:/datos/empleados.txt"
     * @return ArrayList de objetos empleado con todos los empleados cargados exitosamente.
     *         Retorna lista vacía (no null) si:
     *         <ul>
     *           <li>El archivo no existe</li>
     *           <li>Hay error de lectura</li>
     *           <li>El archivo está vacío</li>
     *           <li>Todas las líneas tienen formato inválido</li>
     *         </ul>
     * @see Entidades.empleado
     * @see BufferedReader
     */

    public ArrayList<empleado> cargarEmpleadosDesdeTxt(String ruta) {

    ArrayList<empleado> lista = new ArrayList<>();

    try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {

        String linea;
        while ((linea = br.readLine()) != null) {

            String[] datos = linea.split(",");

            int id = Integer.parseInt(datos[0].trim());
            String nombreCompleto = datos[1].trim();
            String email = datos[2].trim();
            double salario = Double.parseDouble(datos[3].trim());
            String puesto = datos[4].trim();

            String[] partes = nombreCompleto.split(" ");
            String nombre = partes[0];
            String apellido1 = partes.length > 1 ? partes[1] : "";
            String apellido2 = partes.length > 2 ? partes[2] : "";

            empleado emp = new empleado(
                    id,
                    String.valueOf(id),
                    nombre,
                    apellido1,
                    apellido2,
                    email,
                    "",
                    salario,
                    "Mensual",
                    puesto
            );

            lista.add(emp);
        }

    } catch (Exception e) {
        System.out.println("Error leyendo empleados: " + e.getMessage());
    }

    return lista;
}
}
