
package LogicaNegocio;

/**
 * Clase de lógica de negocio para el cálculo de deducciones y aportes de nómina.
 * Implementa todos los cálculos financieros requeridos según la legislación costarricense,
 * incluyendo deducciones de ley, impuesto sobre la renta por tramos y aportes patronales.
 * 
 * <p><b>Deducciones calculadas:</b></p>
 * <ul>
 *   <li>CCSS (IVM + SEM): ~10.67% del salario bruto</li>
 *   <li>Banco Popular: 1% del salario bruto</li>
 *   <li>Impuesto sobre la Renta: Por tramos progresivos (10%, 15%, 20%, 25%)</li>
 * </ul>
 * 
 * <p><b>Aportes patronales calculados:</b></p>
 * <ul>
 *   <li>CCSS patronal (IVM + SEM): ~26.67%</li>
 *   <li>INA: 1.5%</li>
 *   <li>FCL: 3%</li>
 *   <li>Asignaciones Familiares: 5%</li>
 * </ul>
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 * @see Planilla
 * @see Utilidades.montos
 */

import Entidades.Planilla;
import Utilidades.montos;


public class Deducciones {
     /**
     * Calcula solo las deducciones del empleado (CCSS, Banco Popular, Impuesto Renta).
     * 
     * <p>Este método modifica directamente los atributos de la planilla proporcionada,
     * estableciendo los valores calculados de cada deducción.</p>
     * 
     * @param nomina Objeto Planilla que será modificado con los valores calculados.
     *               Debe tener el salarioBruto ya establecido.
     * @see #calcularImpuestoRenta(double)
     * @see Utilidades.montos
     */
    public void calcularDeducciones(Planilla nomina) {
        double salario = nomina.getSalarioBruto();
        
        // Deducciones CCSS
        double deduccionIVM = salario * montos.DEDUCCION_IVM;
        double deduccionSEM = salario * montos.DEDUCCION_SEM;
        nomina.setDeduccionIVM(deduccionIVM);
        nomina.setDeduccionSEM(deduccionSEM);
        nomina.setDeduccionCCSS(deduccionIVM + deduccionSEM);
        
        // Deducción Banco Popular
        nomina.setDeduccionBancoPop(salario * montos.DEDUCCION_BANCO_POPULAR);
        
        // Impuesto sobre la renta
        nomina.setDeduccionImpuestoRenta(calcularImpuestoRenta(salario));
    }

    /**
     * Calcula el impuesto sobre la renta según los tramos progresivos vigentes.
     * Implementa el sistema de impuesto por escalones de la legislación costarricense.
     * 
     * <p><b>Tramos de impuesto (2024):</b></p>
     * <ul>
     *   <li>Hasta ₡941,000: Exento (0%)</li>
     *   <li>₡941,001 - ₡1,405,000: 10% sobre el excedente</li>
     *   <li>₡1,405,001 - ₡2,108,000: 15% sobre el excedente (+ impuesto tramo anterior)</li>
     *   <li>₡2,108,001 - ₡4,215,000: 20% sobre el excedente (+ impuesto tramos anteriores)</li>
     *   <li>Más de ₡4,215,000: 25% sobre el excedente (+ impuesto tramos anteriores)</li>
     * </ul>
     * 
     * @param salario Salario bruto mensual en colones costarricenses.
     * @return Monto total del impuesto sobre la renta a deducir.
     *         Retorna 0 si el salario está por debajo de la base libre.
     * @see Utilidades.montos
     */
    private double calcularImpuestoRenta(double salario) {
        if (salario <= montos.RENTA_BASE_LIBRE) {
            return 0;
        }

        double impuesto = 0;

        // Tramo 1 - 10%
        if (salario > montos.RENTA_BASE_LIBRE) {
            double montoTramo1 = Math.min(
                    salario - montos.RENTA_BASE_LIBRE,
                    montos.RENTA_TRAMO1_LIMITE - montos.RENTA_BASE_LIBRE
            );
            impuesto += montoTramo1 * montos.RENTA_TRAMO1_PORCENTAJE;
        }

        // Tramo 2 - 15%
        if (salario > montos.RENTA_TRAMO1_LIMITE) {
            double montoTramo2 = Math.min(
                    salario - montos.RENTA_TRAMO1_LIMITE,
                   montos.RENTA_TRAMO2_LIMITE - montos.RENTA_TRAMO1_LIMITE
            );
            impuesto += montoTramo2 * montos.RENTA_TRAMO2_PORCENTAJE;
        }

        // Tramo 3 - 20%
        if (salario > montos.RENTA_TRAMO2_LIMITE) {
            double montoTramo3 = Math.min(
                    salario - montos.RENTA_TRAMO2_LIMITE,
                    montos.RENTA_TRAMO3_LIMITE - montos.RENTA_TRAMO2_LIMITE
            );
            impuesto += montoTramo3 * montos.RENTA_TRAMO3_PORCENTAJE;
        }

        // Tramo 4 - 25%
        if (salario > montos.RENTA_TRAMO3_LIMITE) {
            double montoTramo4 = salario - montos.RENTA_TRAMO3_LIMITE;
            impuesto += montoTramo4 * montos.RENTA_TRAMO4_PORCENTAJE;
        }

        return impuesto;
    }

     /**
     * Calcula los aportes patronales requeridos por ley.
     * 
     * <p><b>Aportes calculados:</b></p>
     * <ul>
     *   <li>IVM patronal: 7.08% del salario bruto</li>
     *   <li>SEM patronal: 10.59% del salario bruto</li>
     *   <li>INA: 1.5% del salario bruto</li>
     *   <li>FCL: 3% del salario bruto</li>
     *   <li>Asignaciones Familiares: 5% del salario bruto</li>
     * </ul>
     * 
     * @param nomina Objeto Planilla que será modificado con los aportes calculados.
     * @see Utilidades.montos
     */
     
    public void calcularAportesPatronales(Planilla nomina) {
        double salario = nomina.getSalarioBruto();

        // Aportes CCSS patronales
        double aporteIVM = salario * montos.APORTE_IVM;
        double aporteSEM = salario * montos.APORTE_SEM;
        nomina.setAporteIVM(aporteIVM);
        nomina.setAporteSEM(aporteSEM);
        nomina.setAporteCCSS(aporteIVM + aporteSEM);

        // Otros aportes patronales
        nomina.setAporteINA(salario * montos.APORTE_INA);
        nomina.setAporteFCL(salario * montos.APORTE_FCL);
        nomina.setAporteAsignaciones(salario * montos.APORTE_ASIGNACIONES);
    }

    
     /**
     * Calcula el salario neto del empleado.
     * Resta todas las deducciones del salario bruto para obtener el monto final a pagar.
     *
     * @param nomina Objeto Planilla con todas las deducciones ya calculadas.
     *               Establece el valor de salarioNeto en el objeto.
     */
     
    public void calcularSalarioNeto(Planilla nomina) {
        double salarioNeto = nomina.getSalarioBruto() - nomina.getTotalDeducciones();
        nomina.setSalarioNeto(salarioNeto);
    }

    
     /**
     * Método conveniente que realiza todos los cálculos de la nómina.
     * Ejecuta en secuencia: deducciones, aportes patronales y salario neto.
     * 
     * @param nomina Objeto Planilla con el salario bruto establecido.
     *               Al finalizar contendrá todos los cálculos completos.
     * @see #calcularDeducciones(Planilla)
     * @see #calcularAportesPatronales(Planilla)
     * @see #calcularSalarioNeto(Planilla)
     */
     
    public void calcularNominaCompleta(Planilla nomina) {
        calcularDeducciones(nomina);
        calcularAportesPatronales(nomina);
        calcularSalarioNeto(nomina);
    }
}


