
package LogicaNegocio;
/**
 * Clase responsable de la generación de documentos PDF para el sistema de nómina.
 * Utiliza la librería iText para crear comprobantes de pago individuales y reportes
 * 
 * <p><b>Características de los PDFs:</b></p>
 * <ul>
 *   <li>Formato tamaño carta (Letter)</li>
 *   <li>Tablas estructuradas con información detallada</li>
 *   <li>Formato de moneda costarricense (₡)</li>
 *   <li>Encabezados y títulos profesionales</li>
 * </ul>
 * 
 * @author edu04
 * @version 1.0.0
 * @since 1.0.0
 * @see com.itextpdf.text.Document
 * @see Planilla
 */

import Entidades.Correo;
import Entidades.Planilla; 
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Java class encargada de realizar todo la generación de PDFs
 * @author edu04
 */

public class GeneracionDePDFs {

    private static final DecimalFormat formatoMoneda = new DecimalFormat("₡#,##0.00");
    /**
     * Genera un comprobante de pago individual en formato PDF para un empleado.
     * Crea un documento detallado con toda la información de la planilla
     *                                                              
     * <p><b>Contenido del PDF:</b></p>
     * <ul>
     *   <li>Título: "COMPROBANTE DE PAGO DE SALARIO"</li>
     *   <li>Datos del empleado (ID, nombre, email, puesto, período)</li>
     *   <li>Sección de remuneración (salario bruto)</li>
     *   <li>Tabla de deducciones con montos individuales y total</li>
     *   <li>Tabla de aportes patronales</li>
     *   <li>Salario neto destacado</li>
     * </ul>
     * 
     * @param nomina Objeto Planilla con todos los cálculos completados.
     *               Debe incluir información del empleado y todos los valores calculados.
     * @return String con el nombre del archivo PDF generado.
     * @throws Exception Si ocurre error al crear, escribir o cerrar el documento PDF.
     *                   Posibles causas: permisos insuficientes, disco lleno,
     *                   librería iText no disponible.
     * @see Planilla
     * @see #crearTablaInformacionEmpleado(Planilla)
     * @see #crearTablaDeducciones(Planilla)
     * @see #crearTablaAportesPatronales(Planilla)
     */

    public static String generarReporteEmpleado(Planilla nomina) throws Exception {

        String nombreArchivo = "Nomina_" + nomina.getEmpleado().getCedula() + "_" + nomina.getPeriodo() + ".pdf";

        Document document = new Document(PageSize.LETTER);
        PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
        document.open();

        Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
        Paragraph titulo = new Paragraph("COMPROBANTE DE PAGO DE SALARIO", fontTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(20);
        document.add(titulo);

        Font fontNegrita = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        Paragraph info = new Paragraph();
        info.add(new Chunk("Empleado: ", fontNegrita));
        info.add(nomina.getEmpleado().getNombreCompleto() + "\n");
        info.add(new Chunk("Cédula: ", fontNegrita));
        info.add(nomina.getEmpleado().getCedula() + "\n");
        info.add(new Chunk("Puesto: ", fontNegrita));
        info.add(nomina.getEmpleado().getPuesto() + "\n");
        info.add(new Chunk("Periodo: ", fontNegrita));
        info.add(nomina.getPeriodo() + "\n");
        info.setSpacingAfter(15);
        document.add(info);

        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);

        Font fontHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
        PdfPCell headerConcepto = new PdfPCell(new Phrase("CONCEPTO", fontHeader));
        PdfPCell headerMonto = new PdfPCell(new Phrase("MONTO", fontHeader));
        headerConcepto.setBackgroundColor(BaseColor.DARK_GRAY);
        headerMonto.setBackgroundColor(BaseColor.DARK_GRAY);
        headerConcepto.setHorizontalAlignment(Element.ALIGN_CENTER);
        headerMonto.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(headerConcepto);
        table.addCell(headerMonto);

        agregarFila(table, "Salario Bruto", nomina.getSalarioBruto(), true);

        PdfPCell subtitulo = new PdfPCell(new Phrase("DEDUCCIONES", fontNegrita));
        subtitulo.setBackgroundColor(BaseColor.LIGHT_GRAY);
        subtitulo.setPadding(5);
        table.addCell(subtitulo);
        table.addCell("");

        agregarFila(table, "  CCSS - IVM (4.17%)", nomina.getDeduccionIVM(), false);
        agregarFila(table, "  CCSS - SEM (6.50%)", nomina.getDeduccionSEM(), false);
        agregarFila(table, "  Banco Popular (1%)", nomina.getDeduccionBancoPop(), false);
        agregarFila(table, "  Impuesto Renta", nomina.getDeduccionImpuestoRenta(), false);
        agregarFila(table, "TOTAL DEDUCCIONES", nomina.getTotalDeducciones(), true);

        document.add(table);

        Font fontTotal = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);
        Paragraph total = new Paragraph();
        total.setSpacingBefore(15);
        total.add(new Chunk("SALARIO NETO A PAGAR: ", fontTotal));
        total.add(new Chunk(formatoMoneda.format(nomina.getSalarioNeto()), fontTotal));
        total.setAlignment(Element.ALIGN_RIGHT);
        document.add(total);

       document.close();

        cargarCorreoDesdeArchivo(nomina);

        Correo correo = new Correo();
        correo.setEmail(nomina.getEmpleado().getEmail());

        correo.setAsunto("Comprobante de pago - " + nomina.getPeriodo());
        correo.setMensaje(
                "Estimado/a " + nomina.getEmpleado().getNombreCompleto()
                + "\n\nAdjunto encontrará su comprobante de pago correspondiente al período "
                + nomina.getPeriodo() + ".\n\nSaludos."
        );

        ArrayList<File> adjuntos = new ArrayList<>();
        adjuntos.add(new File(nombreArchivo));
        correo.setArchivosAdjuntos(adjuntos);

        LogicaCorreo logicaCorreo = new LogicaCorreo();
        logicaCorreo.enviarCorreoThread(correo);

        return nombreArchivo;
    }   
     /**
     * Genera un reporte patronal en formato PDF con el desglose de aportes y cargas sociales.
     * Crea un documento que detalla todos los aportes que el patrono debe pagar por el empleado,
     * incluyendo CCSS patronal, INA, FCL y Asignaciones Familiares.
     * 
     * <p>Este reporte es de uso interno del patrono para calcular el costo total de emplear
     * a cada trabajador, que incluye no solo el salario sino también las obligaciones
     * patronales establecidas por ley.</p>
     * 
     * <p><b>Estructura del documento generado:</b></p>
     * <ol>
     *   <li><b>Título:</b> "REPORTE DE CARGAS SOCIALES PATRONALES"
     *     <ul>
     *       <li>Fuente: Helvetica 18pt Bold</li>
     *       <li>Alineación: Centro</li>
     *       <li>Espaciado inferior: 20pt</li>
     *     </ul>
     *   </li>
     *   <li><b>Información del empleado:</b>
     *     <ul>
     *       <li>Nombre completo</li>
     *       <li>Período</li>
     *     </ul>
     *   </li>
     *   <li><b>Tabla de aportes:</b>
     *     <ul>
     *       <li>Salario Base (referencia)</li>
     *       <li>Sección APORTES PATRONALES:
     *         <ul>
     *           <li>CCSS - IVM (7.08%)</li>
     *           <li>CCSS - SEM (10.59%)</li>
     *           <li>INA (1.5%)</li>
     *           <li>FCL (3%)</li>
     *           <li>Asignaciones Familiares (5%)</li>
     *         </ul>
     *       </li>
     *       <li>TOTAL APORTES PATRONALES</li>
     *     </ul>
     *   </li>
     * </ol>
     * 
     * @param nomina Objeto Planilla con aportes patronales calculados.
     * @return String con el nombre del archivo generado.
     *         Formato: "Patronal_[cedula]_[periodo].pdf"
     * @throws Exception Si hay error en creación de PDF, escritura de archivo
     *                   o búsqueda de email del empleado.
     * @see #cargarCorreoDesdeArchivo(Planilla)
     * @see #agregarFila(PdfPTable, String, double, boolean)
     * @see Planilla#getTotalAportesPatronales()
     */

        public static String generarReportePatrono(Planilla nomina) throws Exception {

        String nombreArchivo = "Patronal_" + nomina.getEmpleado().getCedula() + "_" + nomina.getPeriodo() + ".pdf";

        Document document = new Document(PageSize.LETTER);
        PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
        document.open();

        Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
        Paragraph titulo = new Paragraph("REPORTE DE CARGAS SOCIALES PATRONALES", fontTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(20);
        document.add(titulo);

        Font fontNegrita = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        Paragraph info = new Paragraph();
        info.add(new Chunk("Empleado: ", fontNegrita));
        info.add(nomina.getEmpleado().getNombreCompleto() + "\n");
        info.add(new Chunk("Periodo: ", fontNegrita));
        info.add(nomina.getPeriodo() + "\n");
        info.setSpacingAfter(15);
        document.add(info);

        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);

        Font fontHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
        PdfPCell headerConcepto = new PdfPCell(new Phrase("CONCEPTO", fontHeader));
        PdfPCell headerMonto = new PdfPCell(new Phrase("MONTO", fontHeader));
        headerConcepto.setBackgroundColor(BaseColor.DARK_GRAY);
        headerMonto.setBackgroundColor(BaseColor.DARK_GRAY);
        table.addCell(headerConcepto);
        table.addCell(headerMonto);

        agregarFila(table, "Salario Base", nomina.getSalarioBruto(), true);

        PdfPCell subtitulo = new PdfPCell(new Phrase("APORTES PATRONALES", fontNegrita));
        subtitulo.setBackgroundColor(BaseColor.LIGHT_GRAY);
        table.addCell(subtitulo);
        table.addCell("");

        agregarFila(table, "  CCSS - IVM (7.08%)", nomina.getAporteIVM(), false);
        agregarFila(table, "  CCSS - SEM (10.59%)", nomina.getAporteSEM(), false);
        agregarFila(table, "  INA (1.5%)", nomina.getAporteINA(), false);
        agregarFila(table, "  FCL (3%)", nomina.getAporteFCL(), false);
        agregarFila(table, "  Asignaciones (5%)", nomina.getAporteAsignaciones(), false);
        agregarFila(table, "TOTAL APORTES PATRONALES", nomina.getTotalAportesPatronales(), true);

        document.add(table);
       document.close();

        cargarCorreoDesdeArchivo(nomina);

        Correo correo = new Correo();
        correo.setEmail(nomina.getEmpleado().getEmail());
        correo.setAsunto("Reporte patronal - " + nomina.getPeriodo());
        correo.setMensaje(
                "Estimado/a " + nomina.getEmpleado().getNombreCompleto()
                + "\n\nAdjunto encontrará el reporte de cargas sociales patronales "
                + "correspondiente al período " + nomina.getPeriodo() + ".\n\nSaludos."
        );

        ArrayList<File> adjuntos = new ArrayList<>();
        adjuntos.add(new File(nombreArchivo));
        correo.setArchivosAdjuntos(adjuntos);

        LogicaCorreo logicaCorreo = new LogicaCorreo();
        logicaCorreo.enviarCorreoThread(correo);

        return nombreArchivo;

    }
    /**
     * Agrega una fila a la tabla PDF con formato consistente.
     * Método auxiliar utilizado por generarReporteEmpleado() y generarReportePatrono()
     * para mantener uniformidad visual en todas las tablas del documento.
     * 
     * <p><b>Funcionalidad:</b></p>
     * <ul>
     *   <li>Crea dos celdas: una para concepto (texto) y otra para monto (número)</li>
     *   <li>Aplica formato de moneda al valor numérico</li>
     *   <li>Alinea montos a la derecha para facilitar lectura</li>
     *   <li>Aplica padding uniforme (5pt) a ambas celdas</li>
     *   <li>Opcionalmente resalta la fila con fondo gris claro</li>
     * </ul>
     * 
     * @param table Tabla PDF donde se agregará la fila.
     *              Debe ser una PdfPTable con 2 columnas ya inicializada.
     *              No debe ser null.
     * @param concepto Texto descriptivo del concepto (columna izquierda).
     * @param monto Valor numérico del monto en colones (columna derecha).
     *              Será formateado automáticamente con símbolo de moneda,
     *              separadores de miles y dos decimales.
     *              Puede ser 0 o negativo (aunque no es uso común).
     * @param negrita Determina el estilo de la fila:
     * @see PdfPTable
     * @see PdfPCell
     * @see Font
     * @see BaseColor
     */


    private static void agregarFila(PdfPTable table, String concepto, double monto, boolean negrita) {

        Font font = negrita
                ? new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD)
                : new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);

        PdfPCell cellConcepto = new PdfPCell(new Phrase(concepto, font));
        PdfPCell cellMonto = new PdfPCell(new Phrase(formatoMoneda.format(monto), font));

        cellConcepto.setPadding(5);
        cellMonto.setPadding(5);
        cellMonto.setHorizontalAlignment(Element.ALIGN_RIGHT);

        if (negrita) {
            cellConcepto.setBackgroundColor(new BaseColor(240, 240, 240));
            cellMonto.setBackgroundColor(new BaseColor(240, 240, 240));
        }

        table.addCell(cellConcepto);
        table.addCell(cellMonto);
    }
    /**
     * Carga el correo electrónico del empleado desde el archivo empleados.txt.
     * Busca el registro del empleado por coincidencia de nombre y actualiza
     * el email en el objeto Planilla proporcionado.
     * 
     * <p>Este método es esencial para el envío automático de comprobantes,
     * ya que asegura que el email esté actualizado y corresponda al empleado correcto.</p>
     * 
     * <p><b>Algoritmo de búsqueda:</b></p>
     * <ol>
     *   <li>Construir nombre de búsqueda desde planilla:
     *     <ul>
     *       <li>Concatenar: nombre + espacio + apellido1</li>
     *       <li>Trim (eliminar espacios extra)</li>
     *       <li>Convertir a minúsculas para comparación case-insensitive</li>
     *     </ul>
     *   </li>
     *   <li>Abrir archivo empleados.txt para lectura</li>
     *   <li>Leer línea por línea:
     *     <ul>
     *       <li>Saltar líneas vacías</li>
     *       <li>Dividir por comas (formato CSV)</li>
     *       <li>Validar que tenga al menos 5 campos</li>
     *       <li>Extraer nombre (campo 2) y email (campo 3)</li>
     *       <li>Normalizar nombre del archivo (trim + minúsculas)</li>
     *       <li>Comparar nombres</li>
     *       <li>Si coinciden: actualizar email y terminar</li>
     *     </ul>
     *   </li>
     *   <li>Si se termina el archivo sin encontrar: lanzar Exception</li>
     * </ol>
     * 
     * @param nomina Objeto Planilla cuyo empleado necesita email actualizado.
     * @throws Exception Si ocurre cualquiera de estos errores:
     *         <ul>
     *           <li>Archivo empleados.txt no existe (FileNotFoundException)</li>
     *           <li>Error al leer archivo (IOException)</li>
     *           <li>No se encuentra empleado con nombre coincidente:
     *               "No se encontró correo para el empleado: [nombre]"</li>
     *         </ul>
     *         La excepción detiene el proceso de generación de PDF.
     * @see BufferedReader
     * @see String#toLowerCase()
     * @see String#trim()
     */
   private static void cargarCorreoDesdeArchivo(Planilla nomina) throws Exception {

    BufferedReader br = new BufferedReader(new FileReader("empleados.txt"));
    String linea;

    String nombrePlanilla = (
            nomina.getEmpleado().getNombre() + " " +
            nomina.getEmpleado().getApellido1()
    ).trim().toLowerCase();

    while ((linea = br.readLine()) != null) {

        if (linea.isBlank()) continue;

        String[] datos = linea.split(",");

        if (datos.length < 5) continue;

        
        String nombreArchivo = datos[1].trim().toLowerCase();
        String correoArchivo = datos[2].trim();

        if (nombreArchivo.equals(nombrePlanilla)) {
            nomina.getEmpleado().setEmail(correoArchivo);
            br.close();
            return;
        }
    }

    br.close();

    throw new Exception(
        "No se encontró correo para el empleado: " + nombrePlanilla
    );
}
}
