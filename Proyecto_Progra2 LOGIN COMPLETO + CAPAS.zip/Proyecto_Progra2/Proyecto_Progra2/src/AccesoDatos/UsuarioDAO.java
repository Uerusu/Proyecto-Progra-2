/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AccesoDatos;

import Entidades.Usuario;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class UsuarioDAO {

    private static final String ARCHIVO = "usuarios.txt";

   public Usuario buscarPorCredenciales(String usuario, String password) 
        throws IOException {
    try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            if (linea.trim().isEmpty()) continue;

            String[] datos = linea.split(",");
            if (datos.length < 7) continue;

            String userArchivo = datos[5].trim();
            String passArchivo = datos[6].trim();

            if (userArchivo.equals(usuario) && passArchivo.equals(password)) {
                return crearUsuario(datos);
            }
        }
    }
    return null;
}


    private Usuario crearUsuario(String[] datos) {

        Usuario u = new Usuario();
        u.setUsuario(datos[5].trim());
        u.setPassword(datos[6].trim());
        u.setRol(datos[7].trim());
        return u;
    }
}
