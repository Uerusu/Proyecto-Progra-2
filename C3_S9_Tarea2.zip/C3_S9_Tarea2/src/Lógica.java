
import java.io.IOException;
import java.util.List;

/**
 *
 * @author saula
 */

public class Lógica {
    AccesoDatos accesoDatos = new AccesoDatos();
    private List<String[]> listaRegistro = null;
    
    private List<String[]> cargarRegistros() throws IOException {
        if (listaRegistro == null) {
            this.accesoDatos = new AccesoDatos();
            accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());
            accesoDatos.listarRegistros();
            listaRegistro = accesoDatos.getListaRegistros();
        }
        return listaRegistro;
    }
    public void listarUsuario(Usuario usuario) throws IOException {
        for (String[] datos : cargarRegistros()) {
            Usuario usuario1 = new Usuario();
            usuario1.setNombre(datos[0]);
            usuario1.setSalarioBruto(Double.parseDouble(datos[1]));
            
            usuario.agregarListaUsuarios(usuario1);
        }
    }
    public void agregarUsuario(Usuario usuario) throws IOException {
        accesoDatos = new AccesoDatos();
        accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());
        String registro = usuario.getNombre() + "," + usuario.getSalarioBruto();
        accesoDatos.setRegistro(registro);
        accesoDatos.agregarRegistro();
        listaRegistro = null;

    }
     public double aportePatronal(Usuario usuario) {
        return usuario.getSalarioBruto() * 0.2667;
    }
    public double aporteObrero(Usuario usuario) {
        return usuario.getSalarioBruto() * 0.0967;
    }
    public double salarioNeto(Usuario usuario) {
        double bruto = usuario.getSalarioBruto();
        double deducciones = aporteObrero(usuario);
        return bruto - deducciones;
    }
    public double costoTotal(Usuario usuario) {
        double aportePatronal = aportePatronal(usuario);
        return usuario.getSalarioBruto() + aportePatronal;
    }
    
    
    
    
}
