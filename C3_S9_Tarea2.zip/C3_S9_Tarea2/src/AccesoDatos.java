
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author saula
 */
public class AccesoDatos {
    private String registro, nombreArchivo;
    private ArrayList<String[]> listaRegistros;
    public AccesoDatos() {
        listaRegistros = new ArrayList<>();
    }
    public String getRegistro() {
        return registro;
    }
    public void setRegistro(String registro) {
        this.registro = registro;
    }
    public String getNombreArchivo() {
        return nombreArchivo;
    }
    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }
    public ArrayList<String[]> getListaRegistros() {
        return listaRegistros;
    }
    public void setListaRegistros(ArrayList<String[]> listaRegistros) {
        this.listaRegistros = listaRegistros;
    }
    public void agregarRegistro() throws IOException {
        try (BufferedWriter bW = new BufferedWriter(new FileWriter(this.nombreArchivo, true))) {
            bW.append(this.registro);
            bW.newLine();
        }
    }
    public void listarRegistros() throws IOException {
        try (BufferedReader bR = new BufferedReader(new FileReader(this.nombreArchivo))) {
            String linea;
            while ((linea = bR.readLine()) != null) {
                String[] datos = linea.split(",");
                this.listaRegistros.add(datos);
            }
        }
    }
}
