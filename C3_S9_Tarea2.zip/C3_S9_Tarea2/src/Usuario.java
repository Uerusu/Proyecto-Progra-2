
import java.util.ArrayList;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author saula
 */
public class Usuario {
    private double salarioBruto;

    
    private String nombre;
    private ArrayList<Usuario> listaUsuarios;
    
     public Usuario(String nombre, double salarioBruto) {
        this.nombre = nombre;
        this.salarioBruto = salarioBruto;
        
    }
    
     public Usuario() {
        listaUsuarios = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }
    public double getSalarioBruto() {
        return salarioBruto;
    }

    public void setSalarioBruto(double salarioBruto) {
        this.salarioBruto = salarioBruto;
    }

    public void setListaUsuarios(ArrayList<Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }
    
    public void agregarListaUsuarios(Usuario usuario) {
        this.listaUsuarios.add(usuario);
    }
    
    
}
