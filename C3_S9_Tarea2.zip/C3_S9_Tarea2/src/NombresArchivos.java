/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author saula
 */
    public enum NombresArchivos {
    USUARIOS("usuarios.txt");
    private final String nombreArchivo;
    NombresArchivos(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }
    public String getNombreArchivo() {
        return nombreArchivo;
        }
    }