/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicaNegocio;

import Entidades.Planilla;
import Utilidades.montos;

/**
 *
 * @author edu04
 */
public class Deducciones {
    public void calcularDeducciones(Planilla nomina) {
        double salario = nomina.getSalarioBruto();
        
        // Deducciones CCSS
        double deduccionIVM = salario * montos.DEDUCCION_IVM;
        double deduccionSEM = salario * montos.DEDUCCION_SEM;
        nomina.setDeduccionIVM(deduccionIVM);
        nomina.setDeduccionSEM(deduccionSEM);
        nomina.setDeduccionCCSS(deduccionIVM + deduccionSEM);
        
        // Deducción Banco Popular
        nomina.setDeduccionBancoPop(salario * montos.DEDUCCION_BANCO_POPULAR);
        
        // Impuesto sobre la renta
        nomina.setDeduccionImpuestoRenta(calcularImpuestoRenta(salario));
    }

    /**
     * Calcula el impuesto sobre la renta según tramos progresivos.
     */
    private double calcularImpuestoRenta(double salario) {
        if (salario <= montos.RENTA_BASE_LIBRE) {
            return 0;
        }

        double impuesto = 0;

        // Tramo 1 - 10%
        if (salario > montos.RENTA_BASE_LIBRE) {
            double montoTramo1 = Math.min(
                    salario - montos.RENTA_BASE_LIBRE,
                    montos.RENTA_TRAMO1_LIMITE - montos.RENTA_BASE_LIBRE
            );
            impuesto += montoTramo1 * montos.RENTA_TRAMO1_PORCENTAJE;
        }

        // Tramo 2 - 15%
        if (salario > montos.RENTA_TRAMO1_LIMITE) {
            double montoTramo2 = Math.min(
                    salario - montos.RENTA_TRAMO1_LIMITE,
                   montos.RENTA_TRAMO2_LIMITE - montos.RENTA_TRAMO1_LIMITE
            );
            impuesto += montoTramo2 * montos.RENTA_TRAMO2_PORCENTAJE;
        }

        // Tramo 3 - 20%
        if (salario > montos.RENTA_TRAMO2_LIMITE) {
            double montoTramo3 = Math.min(
                    salario - montos.RENTA_TRAMO2_LIMITE,
                    montos.RENTA_TRAMO3_LIMITE - montos.RENTA_TRAMO2_LIMITE
            );
            impuesto += montoTramo3 * montos.RENTA_TRAMO3_PORCENTAJE;
        }

        // Tramo 4 - 25%
        if (salario > montos.RENTA_TRAMO3_LIMITE) {
            double montoTramo4 = salario - montos.RENTA_TRAMO3_LIMITE;
            impuesto += montoTramo4 * montos.RENTA_TRAMO4_PORCENTAJE;
        }

        return impuesto;
    }

    /**
     * Calcula los aportes patronales de un empleado.
     */
    public void calcularAportesPatronales(Planilla nomina) {
        double salario = nomina.getSalarioBruto();

        // Aportes CCSS patronales
        double aporteIVM = salario * montos.APORTE_IVM;
        double aporteSEM = salario * montos.APORTE_SEM;
        nomina.setAporteIVM(aporteIVM);
        nomina.setAporteSEM(aporteSEM);
        nomina.setAporteCCSS(aporteIVM + aporteSEM);

        // Otros aportes patronales
        nomina.setAporteINA(salario * montos.APORTE_INA);
        nomina.setAporteFCL(salario * montos.APORTE_FCL);
        nomina.setAporteAsignaciones(salario * montos.APORTE_ASIGNACIONES);
    }

    /**
     * Calcula el salario neto restando deducciones al salario bruto.
     */
    public void calcularSalarioNeto(Planilla nomina) {
        double salarioNeto = nomina.getSalarioBruto() - nomina.getTotalDeducciones();
        nomina.setSalarioNeto(salarioNeto);
    }

    /**
     * Calcula la nómina completa: deducciones, aportes y salario neto.
     */
    public void calcularNominaCompleta(Planilla nomina) {
        calcularDeducciones(nomina);
        calcularAportesPatronales(nomina);
        calcularSalarioNeto(nomina);
    }
}


