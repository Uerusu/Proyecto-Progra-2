/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicaNegocio;

import Entidades.Planilla;
import Entidades.empleado;
import java.util.ArrayList;

/**
 *
 * @author edu04
 */
public class LogicaPlanilla {

   public ArrayList<Planilla> generarPlanillas(ArrayList<empleado> empleados, String periodo) {

    ArrayList<Planilla> planillas = new ArrayList<>();
    Deducciones deducciones = new Deducciones();

    for (empleado emp : empleados) {

        Planilla p = new Planilla(
                emp.getId(),
                emp,
                periodo
        );

        deducciones.calcularNominaCompleta(p);
        planillas.add(p);
    }

    return planillas;
}
}