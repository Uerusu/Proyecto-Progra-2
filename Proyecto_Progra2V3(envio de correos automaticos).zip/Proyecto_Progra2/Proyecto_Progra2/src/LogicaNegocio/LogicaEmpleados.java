/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package LogicaNegocio;

/**
 *
 * @author edu04
 */
import Entidades.empleado;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

public class LogicaEmpleados {

    public ArrayList<empleado> cargarEmpleadosDesdeTxt(String ruta) {

    ArrayList<empleado> lista = new ArrayList<>();

    try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {

        String linea;
        while ((linea = br.readLine()) != null) {

            String[] datos = linea.split(",");

            int id = Integer.parseInt(datos[0].trim());
            String nombreCompleto = datos[1].trim();
            String email = datos[2].trim();
            double salario = Double.parseDouble(datos[3].trim());
            String puesto = datos[4].trim();

            String[] partes = nombreCompleto.split(" ");
            String nombre = partes[0];
            String apellido1 = partes.length > 1 ? partes[1] : "";
            String apellido2 = partes.length > 2 ? partes[2] : "";

            empleado emp = new empleado(
                    id,
                    String.valueOf(id),
                    nombre,
                    apellido1,
                    apellido2,
                    email,
                    "",
                    salario,
                    "Mensual",
                    puesto
            );

            lista.add(emp);
        }

    } catch (Exception e) {
        System.out.println("Error leyendo empleados: " + e.getMessage());
    }

    return lista;
}
}
