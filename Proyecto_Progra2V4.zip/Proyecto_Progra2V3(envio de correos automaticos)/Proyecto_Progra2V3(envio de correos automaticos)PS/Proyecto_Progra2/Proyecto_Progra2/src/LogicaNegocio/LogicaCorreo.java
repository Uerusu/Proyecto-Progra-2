/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicaNegocio;

import Entidades.Correo;
import java.io.File;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.JOptionPane;

/**
 * Java class encargada del envio de correos
 * @author saula
 */

public class LogicaCorreo {

    private Properties propiedades;
    private Session session;

    private void cargarPropiedades() {
        propiedades = new Properties();
        propiedades.put("mail.smtp.host", "securemail.comredcr.com");
        propiedades.put("mail.smtp.port", "465");
        propiedades.put("mail.smtp.auth", "true");
        propiedades.put("mail.smtp.ssl.enable", "true");
        propiedades.put("mail.smtp.ssl.protocols", "TLSv1.2");
    }

    private void crearSessionSmtp() {
        cargarPropiedades();
        session = Session.getInstance(propiedades, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(
                        "curso_progra2@comredcr.com",
                        "u6X1h1p9@"
                );
            }
        });
    }

    private Multipart construirContenido(Correo datosCorreo) throws MessagingException {

        Multipart multipart = new MimeMultipart();

        MimeBodyPart cuerpo = new MimeBodyPart();
        cuerpo.setText(datosCorreo.getMensaje(), "utf-8");
        multipart.addBodyPart(cuerpo);

        if (datosCorreo.getArchivosAdjuntos() != null && !datosCorreo.getArchivosAdjuntos().isEmpty()) {
            for (File archivo : datosCorreo.getArchivosAdjuntos()) {
                if (archivo != null && archivo.exists()) {
                    MimeBodyPart adjunto = new MimeBodyPart();
                    adjunto.setDataHandler(new DataHandler(new FileDataSource(archivo)));
                    adjunto.setFileName(archivo.getName());
                    multipart.addBodyPart(adjunto);
                }
            }
        }

        return multipart;
    }

    public void enviarCorreo(Correo datosCorreo) throws MessagingException {

        if (datosCorreo == null || datosCorreo.getEmail() == null || datosCorreo.getEmail().isBlank()) {
            throw new MessagingException("El correo destino es nulo o vacío");
        }

        crearSessionSmtp();

        Message mensaje = new MimeMessage(session);
        mensaje.setFrom(new InternetAddress("curso_progra2@comredcr.com"));
        mensaje.setRecipients(
                Message.RecipientType.TO,
                InternetAddress.parse(datosCorreo.getEmail(), false)
        );
        mensaje.setSubject(datosCorreo.getAsunto()); 
        mensaje.setContent(construirContenido(datosCorreo));


        Transport.send(mensaje);
    }

    public void enviarCorreoThread(Correo datosCorreo) {
        new Thread(() -> {
            try {
                enviarCorreo(datosCorreo);
                JOptionPane.showMessageDialog(null, "Correo enviado correctamente");
            } catch (MessagingException e) {
                JOptionPane.showMessageDialog(
                        null,
                        "Error enviando correo:\n" + e.getMessage()
                );
            }
        }).start();
    }
}
