package LogicaNegocio;

import AccesoDatos.UsuarioDAO;
import Entidades.Usuario;
import java.io.IOException;

/**
 * Clase que autentica que rol posee un usuarios 
 * Autentica y obtener son vitales para los diferentes menus del sistema
 * @author edu04
 */
public class AutenticacionBL {

    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    // Solo valida existencia
    public boolean autenticar(String usuario, String password) {
        try {
            Usuario u = usuarioDAO.buscarPorCredenciales(usuario, password);
            return u != null;
        } catch (IOException e) {
            throw new RuntimeException("Error al acceder a usuarios: " + e.getMessage());
        }
    }

    // Devuelve el Usuario completo (para obtener rol)
    public Usuario obtenerUsuario(String usuario, String password) {
        try {
            return usuarioDAO.buscarPorCredenciales(usuario, password);
        } catch (IOException e) {
            throw new RuntimeException("Error al acceder a usuarios: " + e.getMessage());
        }
    }
}
