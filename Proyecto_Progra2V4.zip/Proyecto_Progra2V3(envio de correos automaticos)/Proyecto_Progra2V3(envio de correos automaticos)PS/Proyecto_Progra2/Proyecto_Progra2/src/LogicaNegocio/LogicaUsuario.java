/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicaNegocio;

import AccesoDatos.AccesoDatos;
import AccesoDatos.IdControl;
import Entidades.Usuario;
import Utilidades.NombresArchivos;
import java.io.IOException;

/**
 *  Logica de la condiguración de Usuarios 
 * @author Saul
 * @version 1.0.0
 */
public class LogicaUsuario {

    private AccesoDatos accesoDatos;
    private IdControl idControl;

    public void agregarUsuario(Usuario usuario) throws IOException {

    accesoDatos = new AccesoDatos();
    idControl = new IdControl();
    accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());

    usuario.setId(idControl.getNextId(NombresArchivos.USUARIOS.getNombreArchivo()));


    // 🔹 Guardar el registro completo (8 campos)
    accesoDatos.setRegistro(
            usuario.getId() + "," +
            usuario.getNombre() + "," +
            usuario.getApellido1() + "," +
            usuario.getApellido2() + "," +
            usuario.getEmail() + "," +
            usuario.getUsuario() + "," +
            usuario.getPassword() + "," +
            usuario.getRol()
    );

    accesoDatos.agregarRegistro();
}


    public void actualizarUsuario(Usuario usuario) throws IOException {

    accesoDatos = new AccesoDatos();
    accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());
    accesoDatos.setIdRegistro(usuario.getId());

    accesoDatos.setRegistro(
            usuario.getId() + "," +
            usuario.getNombre() + "," +
            usuario.getApellido1() + "," +
            usuario.getApellido2() + "," +
            usuario.getEmail() + "," +
            usuario.getUsuario() + "," +
            usuario.getPassword() + "," +
            usuario.getRol()        
    );

    accesoDatos.setEliminar(false);
    accesoDatos.modificarRegistro();
}


    public void eliminarUsuario(Usuario usuario) throws IOException {
        
        accesoDatos = new AccesoDatos();
        accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());
        accesoDatos.setIdRegistro(usuario.getId());
        accesoDatos.setEliminar(true);
        accesoDatos.modificarRegistro();
        
    }

    public void listarUsuario(Usuario usuario) throws IOException {

        accesoDatos = new AccesoDatos();
        accesoDatos.setNombreArchivo(NombresArchivos.USUARIOS.getNombreArchivo());
        accesoDatos.listarRegistros();
        for(String[] datos : accesoDatos.getListaRegistros()){
            Usuario usr = new Usuario(Integer.parseInt(datos[0]), datos[1], datos[2], datos[3], datos[4], datos[5], datos[6],datos[7]);
            usuario.agregarListaUsuarios(usr);   
        }
        

    }
    public Usuario obtenerUsuarioPorId(int id) throws IOException {
    // Definimos el nombre del archivo de usuarios
    String nombreArchivoUsuarios = NombresArchivos.USUARIOS.getNombreArchivo();
    
    // Llamamos al nuevo método de AccesoDatos para obtener la línea completa
    String lineaUsuario = accesoDatos.buscarRegistroPorId(id, nombreArchivoUsuarios);

    if (lineaUsuario != null) {
        // La línea contiene: ID, Nombre, Apellido1, Apellido2, Email, Usuario, Password
        String[] datos = lineaUsuario.split(",");

        // Verificar que la línea tiene suficientes campos (al menos 7)
        if (datos.length >= 7) {
            try {
                int idUsuario = Integer.parseInt(datos[0].trim());
                String nombre = datos[1].trim();
                String apellido1 = datos[2].trim();
                String apellido2 = datos[3].trim();
                String email = datos[4].trim();
                String nombreUsuario = datos[5].trim();
                String password = datos[6].trim();
                String rol = datos[7].trim();// <-- ¡Aquí rescatamos la contraseña!

                return new Usuario(idUsuario, nombre, apellido1, apellido2, email, nombreUsuario, password, rol);
            } catch (NumberFormatException e) {
                System.err.println("Error de formato al parsear el ID del usuario: " + e.getMessage());
                return null;
            }
        } else {
            System.err.println("Error: El registro de usuario con ID " + id + " no tiene el formato correcto.");
            return null;
        }
    }
    
    return null; // Usuario no encontrado
}
    

}
