/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicaNegocio;

import Entidades.Correo;
import Entidades.Planilla; 
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * Java class encargada de realizar todo la generación de PDFs
 * @author edu04
 */

public class GeneracionDePDFs {

    private static final DecimalFormat formatoMoneda = new DecimalFormat("₡#,##0.00");

    public static String generarReporteEmpleado(Planilla nomina) throws Exception {

        String nombreArchivo = "Nomina_" + nomina.getEmpleado().getCedula() + "_" + nomina.getPeriodo() + ".pdf";

        Document document = new Document(PageSize.LETTER);
        PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
        document.open();

        Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
        Paragraph titulo = new Paragraph("COMPROBANTE DE PAGO DE SALARIO", fontTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(20);
        document.add(titulo);

        Font fontNegrita = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        Paragraph info = new Paragraph();
        info.add(new Chunk("Empleado: ", fontNegrita));
        info.add(nomina.getEmpleado().getNombreCompleto() + "\n");
        info.add(new Chunk("Cédula: ", fontNegrita));
        info.add(nomina.getEmpleado().getCedula() + "\n");
        info.add(new Chunk("Puesto: ", fontNegrita));
        info.add(nomina.getEmpleado().getPuesto() + "\n");
        info.add(new Chunk("Periodo: ", fontNegrita));
        info.add(nomina.getPeriodo() + "\n");
        info.setSpacingAfter(15);
        document.add(info);

        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);

        Font fontHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
        PdfPCell headerConcepto = new PdfPCell(new Phrase("CONCEPTO", fontHeader));
        PdfPCell headerMonto = new PdfPCell(new Phrase("MONTO", fontHeader));
        headerConcepto.setBackgroundColor(BaseColor.DARK_GRAY);
        headerMonto.setBackgroundColor(BaseColor.DARK_GRAY);
        headerConcepto.setHorizontalAlignment(Element.ALIGN_CENTER);
        headerMonto.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(headerConcepto);
        table.addCell(headerMonto);

        agregarFila(table, "Salario Bruto", nomina.getSalarioBruto(), true);

        PdfPCell subtitulo = new PdfPCell(new Phrase("DEDUCCIONES", fontNegrita));
        subtitulo.setBackgroundColor(BaseColor.LIGHT_GRAY);
        subtitulo.setPadding(5);
        table.addCell(subtitulo);
        table.addCell("");

        agregarFila(table, "  CCSS - IVM (4.17%)", nomina.getDeduccionIVM(), false);
        agregarFila(table, "  CCSS - SEM (6.50%)", nomina.getDeduccionSEM(), false);
        agregarFila(table, "  Banco Popular (1%)", nomina.getDeduccionBancoPop(), false);
        agregarFila(table, "  Impuesto Renta", nomina.getDeduccionImpuestoRenta(), false);
        agregarFila(table, "TOTAL DEDUCCIONES", nomina.getTotalDeducciones(), true);

        document.add(table);

        Font fontTotal = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);
        Paragraph total = new Paragraph();
        total.setSpacingBefore(15);
        total.add(new Chunk("SALARIO NETO A PAGAR: ", fontTotal));
        total.add(new Chunk(formatoMoneda.format(nomina.getSalarioNeto()), fontTotal));
        total.setAlignment(Element.ALIGN_RIGHT);
        document.add(total);

       document.close();

        cargarCorreoDesdeArchivo(nomina);

        Correo correo = new Correo();
        correo.setEmail(nomina.getEmpleado().getEmail());

        correo.setAsunto("Comprobante de pago - " + nomina.getPeriodo());
        correo.setMensaje(
                "Estimado/a " + nomina.getEmpleado().getNombreCompleto()
                + "\n\nAdjunto encontrará su comprobante de pago correspondiente al período "
                + nomina.getPeriodo() + ".\n\nSaludos."
        );

        ArrayList<File> adjuntos = new ArrayList<>();
        adjuntos.add(new File(nombreArchivo));
        correo.setArchivosAdjuntos(adjuntos);

        LogicaCorreo logicaCorreo = new LogicaCorreo();
        logicaCorreo.enviarCorreoThread(correo);

        return nombreArchivo;
    }

    public static String generarReportePatrono(Planilla nomina) throws Exception {

        String nombreArchivo = "Patronal_" + nomina.getEmpleado().getCedula() + "_" + nomina.getPeriodo() + ".pdf";

        Document document = new Document(PageSize.LETTER);
        PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
        document.open();

        Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
        Paragraph titulo = new Paragraph("REPORTE DE CARGAS SOCIALES PATRONALES", fontTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(20);
        document.add(titulo);

        Font fontNegrita = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        Paragraph info = new Paragraph();
        info.add(new Chunk("Empleado: ", fontNegrita));
        info.add(nomina.getEmpleado().getNombreCompleto() + "\n");
        info.add(new Chunk("Periodo: ", fontNegrita));
        info.add(nomina.getPeriodo() + "\n");
        info.setSpacingAfter(15);
        document.add(info);

        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);

        Font fontHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
        PdfPCell headerConcepto = new PdfPCell(new Phrase("CONCEPTO", fontHeader));
        PdfPCell headerMonto = new PdfPCell(new Phrase("MONTO", fontHeader));
        headerConcepto.setBackgroundColor(BaseColor.DARK_GRAY);
        headerMonto.setBackgroundColor(BaseColor.DARK_GRAY);
        table.addCell(headerConcepto);
        table.addCell(headerMonto);

        agregarFila(table, "Salario Base", nomina.getSalarioBruto(), true);

        PdfPCell subtitulo = new PdfPCell(new Phrase("APORTES PATRONALES", fontNegrita));
        subtitulo.setBackgroundColor(BaseColor.LIGHT_GRAY);
        table.addCell(subtitulo);
        table.addCell("");

        agregarFila(table, "  CCSS - IVM (7.08%)", nomina.getAporteIVM(), false);
        agregarFila(table, "  CCSS - SEM (10.59%)", nomina.getAporteSEM(), false);
        agregarFila(table, "  INA (1.5%)", nomina.getAporteINA(), false);
        agregarFila(table, "  FCL (3%)", nomina.getAporteFCL(), false);
        agregarFila(table, "  Asignaciones (5%)", nomina.getAporteAsignaciones(), false);
        agregarFila(table, "TOTAL APORTES PATRONALES", nomina.getTotalAportesPatronales(), true);

        document.add(table);
       document.close();

        cargarCorreoDesdeArchivo(nomina);

        Correo correo = new Correo();
        correo.setEmail(nomina.getEmpleado().getEmail());
        correo.setAsunto("Reporte patronal - " + nomina.getPeriodo());
        correo.setMensaje(
                "Estimado/a " + nomina.getEmpleado().getNombreCompleto()
                + "\n\nAdjunto encontrará el reporte de cargas sociales patronales "
                + "correspondiente al período " + nomina.getPeriodo() + ".\n\nSaludos."
        );

        ArrayList<File> adjuntos = new ArrayList<>();
        adjuntos.add(new File(nombreArchivo));
        correo.setArchivosAdjuntos(adjuntos);

        LogicaCorreo logicaCorreo = new LogicaCorreo();
        logicaCorreo.enviarCorreoThread(correo);

        return nombreArchivo;

    }

    private static void agregarFila(PdfPTable table, String concepto, double monto, boolean negrita) {

        Font font = negrita
                ? new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD)
                : new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);

        PdfPCell cellConcepto = new PdfPCell(new Phrase(concepto, font));
        PdfPCell cellMonto = new PdfPCell(new Phrase(formatoMoneda.format(monto), font));

        cellConcepto.setPadding(5);
        cellMonto.setPadding(5);
        cellMonto.setHorizontalAlignment(Element.ALIGN_RIGHT);

        if (negrita) {
            cellConcepto.setBackgroundColor(new BaseColor(240, 240, 240));
            cellMonto.setBackgroundColor(new BaseColor(240, 240, 240));
        }

        table.addCell(cellConcepto);
        table.addCell(cellMonto);
    }
   private static void cargarCorreoDesdeArchivo(Planilla nomina) throws Exception {

    BufferedReader br = new BufferedReader(new FileReader("empleados.txt"));
    String linea;

    String nombrePlanilla = (
            nomina.getEmpleado().getNombre() + " " +
            nomina.getEmpleado().getApellido1()
    ).trim().toLowerCase();

    while ((linea = br.readLine()) != null) {

        if (linea.isBlank()) continue;

        String[] datos = linea.split(",");

        if (datos.length < 5) continue;

        
        String nombreArchivo = datos[1].trim().toLowerCase();
        String correoArchivo = datos[2].trim();

        if (nombreArchivo.equals(nombrePlanilla)) {
            nomina.getEmpleado().setEmail(correoArchivo);
            br.close();
            return;
        }
    }

    br.close();

    throw new Exception(
        "No se encontró correo para el empleado: " + nombrePlanilla
    );
}
}
