/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AccesoDatos;

/**
 *
 * @author saula
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AccesoDatos {
    
    /**
     * Java class encargada del Acceso de Datos de todo el proyecto
     * @author Saul 
     * @param Todoos los getters y setters del Acesso de Datos 
     * @version 1.0.0
     */
    private static final String EMPLEADOS = "empleados.txt";
    private String registro, nombreArchivo;
    private ArrayList<String[]> listaRegistros;
    private int idRegistro;
    private boolean eliminar;

    public AccesoDatos() {

        listaRegistros = new ArrayList<>();
    }

    public String getRegistro() {
        return registro;
    }

    public void setRegistro(String registro) {
        this.registro = registro;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public ArrayList<String[]> getListaRegistros() {
        return listaRegistros;
    }

    public void setListaRegistros(ArrayList<String[]> listaRegistros) {
        this.listaRegistros = listaRegistros;
    }

    public int getIdRegistro() {
        return idRegistro;
    }

    public void setIdRegistro(int idRegistro) {
        this.idRegistro = idRegistro;
    }

    public boolean isEliminar() {
        return eliminar;
    }

    public void setEliminar(boolean eliminar) {
        this.eliminar = eliminar;
    }

    public void agregarRegistro() throws IOException {

        try (BufferedWriter bW = new BufferedWriter(new FileWriter(this.nombreArchivo, true))) {

            bW.append(this.registro);
            bW.newLine();

        }

    }

    public void listarRegistros() throws IOException {

        try (BufferedReader bR = new BufferedReader(new FileReader(this.nombreArchivo))) {

            String linea;

            while ((linea = bR.readLine()) != null) {

                String[] datos = linea.split(",");

                this.listaRegistros.add(datos);

            }

        }

    }
    
    public void actualizarEmpleado(int id, String nombreCompleto, String email) throws IOException {
    List<String> lineas = new ArrayList<>();
    boolean encontrado = false;
    
    // Leer todas las líneas
    try (BufferedReader br = new BufferedReader(new FileReader(EMPLEADOS))) {
        String linea;
        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(",");
            
            // Si encontramos el ID, actualizamos nombre y email
            if (datos[0].equals(String.valueOf(id))) {
                // Mantener: id, nombre actualizado, email actualizado, salario, rol
                linea = datos[0] + "," + nombreCompleto + "," + email + "," + 
                       datos[3] + "," + datos[4];
                encontrado = true;
            }
            lineas.add(linea);
        }
    }
    
    // Escribir todo de vuelta
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(EMPLEADOS))) {
        for (String linea : lineas) {
            bw.write(linea);
            bw.newLine();
        }
    }
}

    public void modificarRegistro() throws IOException {
        
        File archivoOriginal = new File(this.nombreArchivo);
        File archivoTemp = new File("temp_" + this.nombreArchivo);
        

        try (BufferedReader bR = new BufferedReader(new FileReader(archivoOriginal));
                BufferedWriter bW = new BufferedWriter(new FileWriter(archivoTemp))) {

            String linea;

            while ((linea = bR.readLine()) != null) {

                String[] datos = linea.split(",");

                if (this.idRegistro == Integer.parseInt(datos[0])) {

                    if (this.eliminar) {

                        continue;

                    } else {

                        bW.append(this.registro);
                        bW.newLine();

                    }

                } else {
                    bW.append(linea);
                    bW.newLine();
                }

            }
            
        }
        
         if (!archivoOriginal.delete()){
                throw new IOException("No se puede eliminar");
            }
            
            if (!archivoTemp.renameTo(archivoOriginal)){
                throw new IOException("No se puede renombrar el archivo");
            }

    }
    public String buscarRegistroPorId(int id, String nombreArchivo) throws IOException {
    try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
        String linea;
        String idBuscado = String.valueOf(id);

        while ((linea = br.readLine()) != null) {
            // Asumiendo que el ID es siempre el primer campo, seguido de una coma.
            if (linea.startsWith(idBuscado + ",")) {
                return linea; // Se encontró el registro completo
            }
        }
    }
    return null; // No se encontró el registro con ese ID
}


}