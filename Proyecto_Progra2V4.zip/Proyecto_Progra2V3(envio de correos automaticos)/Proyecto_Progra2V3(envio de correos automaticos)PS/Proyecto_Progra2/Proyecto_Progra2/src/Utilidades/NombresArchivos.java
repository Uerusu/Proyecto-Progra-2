/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

/**
 *  Todos los archivos de txt que se van a utilizar para la persistencía
 * @author Saul
 */
public enum NombresArchivos {
    ID_CONTROL("IdControl.txt"),
    USUARIOS("usuarios.txt"),
    BASE_MARCAS("AGL_001.TXT"),
    EMPLEADOS("empleados.txt");

    private final String nombreArchivo;

    NombresArchivos(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

}
