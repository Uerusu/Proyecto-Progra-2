/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entidades;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *  Todos los datos necesarios para la planilla y procesos internos de esta.
 * @author edu04
 */
public class Planilla {
    
    private int id;
    private empleado empleado;
    private LocalDate fechaEmision;
    private String periodo;
    
    private double salarioBruto;
    private double salarioNeto;
    
    // Deducciones
    private double deduccionCCSS;
    private double deduccionIVM;
    private double deduccionSEM;
    private double deduccionBancoPop;
    private double deduccionImpuestoRenta;
    
    // Aportes patronales
    private double aporteCCSS;
    private double aporteIVM;
    private double aporteSEM;
    private double aporteINA;
    private double aporteFCL;
    private double aporteAsignaciones;
    
    public Planilla(int id, empleado empleado, String periodo) {
        this.id = id;
        this.empleado = empleado;
        this.periodo = periodo;
        this.fechaEmision = LocalDate.now();
        this.salarioBruto = empleado.getSalarioBruto();
    }
    
    public Planilla() {}
    
    // Getters y Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public empleado getEmpleado() { return empleado; }
    public void setEmpleado(empleado empleado) { this.empleado = empleado; }
    
    public LocalDate getFechaEmision() { return fechaEmision; }
    public void setFechaEmision(LocalDate fechaEmision) { this.fechaEmision = fechaEmision; }
    
    public String getPeriodo() { return periodo; }
    public void setPeriodo(String periodo) { this.periodo = periodo; }
    
    public double getSalarioBruto() { return salarioBruto; }
    public void setSalarioBruto(double salarioBruto) { this.salarioBruto = salarioBruto; }
    
    public double getSalarioNeto() { return salarioNeto; }
    public void setSalarioNeto(double salarioNeto) { this.salarioNeto = salarioNeto; }
    
    public double getDeduccionCCSS() { return deduccionCCSS; }
    public void setDeduccionCCSS(double deduccionCCSS) { this.deduccionCCSS = deduccionCCSS; }
    
    public double getDeduccionIVM() { return deduccionIVM; }
    public void setDeduccionIVM(double deduccionIVM) { this.deduccionIVM = deduccionIVM; }
    
    public double getDeduccionSEM() { return deduccionSEM; }
    public void setDeduccionSEM(double deduccionSEM) { this.deduccionSEM = deduccionSEM; }
    
    public double getDeduccionBancoPop() { return deduccionBancoPop; }
    public void setDeduccionBancoPop(double deduccionBancoPop) { 
        this.deduccionBancoPop = deduccionBancoPop; 
    }
    
    public double getDeduccionImpuestoRenta() { return deduccionImpuestoRenta; }
    public void setDeduccionImpuestoRenta(double deduccionImpuestoRenta) { 
        this.deduccionImpuestoRenta = deduccionImpuestoRenta; 
    }
    
    public double getAporteCCSS() { return aporteCCSS; }
    public void setAporteCCSS(double aporteCCSS) { this.aporteCCSS = aporteCCSS; }
    
    public double getAporteIVM() { return aporteIVM; }
    public void setAporteIVM(double aporteIVM) { this.aporteIVM = aporteIVM; }
    
    public double getAporteSEM() { return aporteSEM; }
    public void setAporteSEM(double aporteSEM) { this.aporteSEM = aporteSEM; }
    
    public double getAporteINA() { return aporteINA; }
    public void setAporteINA(double aporteINA) { this.aporteINA = aporteINA; }
    
    public double getAporteFCL() { return aporteFCL; }
    public void setAporteFCL(double aporteFCL) { this.aporteFCL = aporteFCL; }
    
    public double getAporteAsignaciones() { return aporteAsignaciones; }
    public void setAporteAsignaciones(double aporteAsignaciones) { 
        this.aporteAsignaciones = aporteAsignaciones; 
    }
    
    public double getTotalDeducciones() {
        return deduccionCCSS + deduccionBancoPop + deduccionImpuestoRenta;
    }
    
    public double getTotalAportesPatronales() {
        return aporteCCSS + aporteINA + aporteFCL + aporteAsignaciones;
    }
    
    public String getFechaEmisionFormateada() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return fechaEmision.format(formatter);
        
        
    }
}


