/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicaNegocio;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author edu04
 */
public class MenuDeUsuarios {

public static void cambioContraseña() throws FileNotFoundException, IOException {

        String usuarioBuscado = JOptionPane.showInputDialog(null,
                "Ingresar el nombre de usuario:");

        if (usuarioBuscado == null || usuarioBuscado.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "No ingresó un usuario.");
            return;
        }

                
                String nuevaContrasena = JOptionPane.showInputDialog(null,
                        "Ingrese la nueva contraseña:");

                if (nuevaContrasena == null || nuevaContrasena.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No ingresó una contraseña válida.");
                    return;
                }

                // Leer archivo y modificar contraseña
                File archivo = new File("usuarios.txt");
                List<String> lineas = new ArrayList<>();
                boolean encontrado = false;

                try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
                    String linea;
                    while ((linea = br.readLine()) != null) {
                        String[] partes = linea.split(",");
                        if (partes.length >= 7 && partes[5].equals(usuarioBuscado)) {
                            // Cambiar la contraseña
                            partes[6] = nuevaContrasena;
                            linea = String.join(",", partes);
                            encontrado = true;
                        }
                        lineas.add(linea);
                    }

                    if (!encontrado) {
                        JOptionPane.showMessageDialog(null, "Usuario no encontrado: " + usuarioBuscado);
                        return;
                    }

                    
                    try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))) {
                        for (String l : lineas) {
                            bw.write(l);
                            bw.newLine();
                        }
                        JOptionPane.showMessageDialog(null, "Contraseña cambiada correctamente para: " + usuarioBuscado);
                    } catch (IOException e) {
                        JOptionPane.showMessageDialog(null, "Error al guardar el archivo: " + e.getMessage());
                    }

                    
                }
}
}

    

    

   



