/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicaNegocio;

import Entidades.Planilla;
import Entidades.Usuario;
import Presentacion.FrmApp;
import Presentacion.FrmMenuAdmin;
import Presentacion.FrmMenuEmpleado;
import Presentacion.FrmMenuPatrono;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 * Interfaz de login y menú para roles.
 * Mantiene la lógica original, abre FrmApp y permite usar el menú del patrono
 * repetidas veces hasta que el usuario elija salir.
 */
public class LoginUI {

    private AutenticacionBL service = new AutenticacionBL();

    public void login() throws IOException, InterruptedException {

        int intentos = 0;
        boolean acceso = false;
        String usuarioIngresado = null;
        String passwordIngresado = null;

        while (intentos < 3 && !acceso) {

            usuarioIngresado = JOptionPane.showInputDialog(null, "INGRESE SU USUARIO:");
            passwordIngresado = JOptionPane.showInputDialog(null, "INGRESE SU CONTRASEÑA:");

            if (usuarioIngresado == null || passwordIngresado == null) {
                JOptionPane.showMessageDialog(null, "ACCESO CANCELADO.");
                return;
            }

            acceso = service.autenticar(usuarioIngresado.trim(), passwordIngresado.trim());

            if (!acceso) {
                intentos++;
                if (intentos < 3) {
                    JOptionPane.showMessageDialog(null,
                            "**ACCESO DENEGADO**\nIntento " + intentos + " de 3");
                }
            }
        }

        if (!acceso) {
            JOptionPane.showMessageDialog(null, "**ACCESO BLOQUEADO**");
            return;
        }

        // Obtener el Usuario completo (con rol)
        Usuario u = service.obtenerUsuario(usuarioIngresado.trim(), passwordIngresado.trim());

        if (u != null) {
            mostrarBienvenida(u);
        } else {
            JOptionPane.showMessageDialog(null, "ACCESO CONCEDIDO (sin rol)");
            // Si querés abrir FrmApp también aquí, descomenta:
            // javax.swing.SwingUtilities.invokeLater(() -> new FrmApp().setVisible(true));
        }
    }

    private void mostrarBienvenida(Usuario usuario) throws IOException, InterruptedException {
        // Mensaje general de bienvenida
        String rol = (usuario.getRol() == null) ? "DESCONOCIDO" : usuario.getRol();
        JOptionPane.showMessageDialog(null, "Bienvenido " + rol.toUpperCase());

        switch (rol) {
            
            case "admin":
               // MenuDeUsuarios.menuAdministrador();
                 java.awt.EventQueue.invokeLater(() -> new FrmMenuAdmin().setVisible(true));
                

                break;

            case "empleado":
                //MenuDeUsuarios.MostrarMenuEmpleado();
                java.awt.EventQueue.invokeLater(() -> new FrmMenuEmpleado().setVisible(true));
                break;


            case "patrono":
               // MenuDeUsuarios.mostrarMenuPatrono();
                java.awt.EventQueue.invokeLater(() -> new FrmMenuPatrono().setVisible(true));
                break;


            default:
                //JOptionPane.showMessageDialog(null, "OPCION INVALIDA");
                break;
        }
    }
}

    