/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LogicaNegocio;

import Entidades.Planilla; // Ajusta según tu entidad real
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.text.DecimalFormat;

public class GeneracionDePDFs {

    private static final DecimalFormat formatoMoneda = new DecimalFormat("₡#,##0.00");

    /**
     * Genera el PDF de reporte para el empleado
     */
    public static String generarReporteEmpleado(Planilla nomina) throws Exception {
        String nombreArchivo = "Nomina_" + nomina.getEmpleado().getCedula() +
                               "_" + nomina.getPeriodo() + ".pdf";

        Document document = new Document(PageSize.LETTER);
        PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
        document.open();

        // Título
        Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
        Paragraph titulo = new Paragraph("COMPROBANTE DE PAGO DE SALARIO", fontTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(20);
        document.add(titulo);

        // Información del empleado
        Font fontNegrita = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        Paragraph info = new Paragraph();
        info.add(new Chunk("Empleado: ", fontNegrita));
        info.add(nomina.getEmpleado().getNombreCompleto() + "\n");
        info.add(new Chunk("Cédula: ", fontNegrita));
        info.add(nomina.getEmpleado().getCedula() + "\n");
        info.add(new Chunk("Puesto: ", fontNegrita));
        info.add(nomina.getEmpleado().getPuesto() + "\n");
        info.add(new Chunk("Periodo: ", fontNegrita));
        info.add(nomina.getPeriodo() + "\n");
        info.setSpacingAfter(15);
        document.add(info);

        // Tabla de detalle
        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);

        // Encabezados
        Font fontHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
        PdfPCell headerConcepto = new PdfPCell(new Phrase("CONCEPTO", fontHeader));
        PdfPCell headerMonto = new PdfPCell(new Phrase("MONTO", fontHeader));
        headerConcepto.setBackgroundColor(BaseColor.DARK_GRAY);
        headerMonto.setBackgroundColor(BaseColor.DARK_GRAY);
        headerConcepto.setHorizontalAlignment(Element.ALIGN_CENTER);
        headerMonto.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(headerConcepto);
        table.addCell(headerMonto);

        // Salario bruto
        agregarFila(table, "Salario Bruto", nomina.getSalarioBruto(), true);

        // Deducciones
        PdfPCell subtitulo = new PdfPCell(new Phrase("DEDUCCIONES", fontNegrita));
        subtitulo.setBackgroundColor(BaseColor.LIGHT_GRAY);
        subtitulo.setPadding(5);
        table.addCell(subtitulo);
        table.addCell("");

        agregarFila(table, "  CCSS - IVM (4.17%)", nomina.getDeduccionIVM(), false);
        agregarFila(table, "  CCSS - SEM (6.50%)", nomina.getDeduccionSEM(), false);
        agregarFila(table, "  Banco Popular (1%)", nomina.getDeduccionBancoPop(), false);
        agregarFila(table, "  Impuesto Renta", nomina.getDeduccionImpuestoRenta(), false);
        agregarFila(table, "TOTAL DEDUCCIONES", nomina.getTotalDeducciones(), true);

        document.add(table);

        // Salario neto
        Font fontTotal = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);
        Paragraph total = new Paragraph();
        total.setSpacingBefore(15);
        total.add(new Chunk("SALARIO NETO A PAGAR: ", fontTotal));
        total.add(new Chunk(formatoMoneda.format(nomina.getSalarioNeto()), fontTotal));
        total.setAlignment(Element.ALIGN_RIGHT);
        document.add(total);

        document.close();
        return nombreArchivo;
    }

    /**
     * Genera el PDF de reporte para el patrono
     */
    public static String generarReportePatrono(Planilla nomina) throws Exception {
        String nombreArchivo = "Patronal_" + nomina.getEmpleado().getCedula() +
                               "_" + nomina.getPeriodo() + ".pdf";

        Document document = new Document(PageSize.LETTER);
        PdfWriter.getInstance(document, new FileOutputStream(nombreArchivo));
        document.open();

        // Título
        Font fontTitulo = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
        Paragraph titulo = new Paragraph("REPORTE DE CARGAS SOCIALES PATRONALES", fontTitulo);
        titulo.setAlignment(Element.ALIGN_CENTER);
        titulo.setSpacingAfter(20);
        document.add(titulo);

        // Información empleado
        Font fontNegrita = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD);
        Paragraph info = new Paragraph();
        info.add(new Chunk("Empleado: ", fontNegrita));
        info.add(nomina.getEmpleado().getNombreCompleto() + "\n");
        info.add(new Chunk("Periodo: ", fontNegrita));
        info.add(nomina.getPeriodo() + "\n");
        info.setSpacingAfter(15);
        document.add(info);

        // Tabla de aportes
        PdfPTable table = new PdfPTable(2);
        table.setWidthPercentage(100);

        // Encabezados
        Font fontHeader = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
        PdfPCell headerConcepto = new PdfPCell(new Phrase("CONCEPTO", fontHeader));
        PdfPCell headerMonto = new PdfPCell(new Phrase("MONTO", fontHeader));
        headerConcepto.setBackgroundColor(BaseColor.DARK_GRAY);
        headerMonto.setBackgroundColor(BaseColor.DARK_GRAY);
        table.addCell(headerConcepto);
        table.addCell(headerMonto);

        agregarFila(table, "Salario Base", nomina.getSalarioBruto(), true);

        PdfPCell subtitulo = new PdfPCell(new Phrase("APORTES PATRONALES", fontNegrita));
        subtitulo.setBackgroundColor(BaseColor.LIGHT_GRAY);
        table.addCell(subtitulo);
        table.addCell("");

        agregarFila(table, "  CCSS - IVM (7.08%)", nomina.getAporteIVM(), false);
        agregarFila(table, "  CCSS - SEM (10.59%)", nomina.getAporteSEM(), false);
        agregarFila(table, "  INA (1.5%)", nomina.getAporteINA(), false);
        agregarFila(table, "  FCL (3%)", nomina.getAporteFCL(), false);
        agregarFila(table, "  Asignaciones (5%)", nomina.getAporteAsignaciones(), false);
        agregarFila(table, "TOTAL APORTES PATRONALES", nomina.getTotalAportesPatronales(), true);

        document.add(table);
        document.close();

        return nombreArchivo;
    }

    /**
     * Método auxiliar para agregar filas a la tabla
     */
    private static void agregarFila(PdfPTable table, String concepto, double monto, boolean negrita) {
        Font font = negrita ?
                new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD) :
                new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);

        PdfPCell cellConcepto = new PdfPCell(new Phrase(concepto, font));
        PdfPCell cellMonto = new PdfPCell(new Phrase(formatoMoneda.format(monto), font));

        cellConcepto.setPadding(5);
        cellMonto.setPadding(5);
        cellMonto.setHorizontalAlignment(Element.ALIGN_RIGHT);

        if (negrita) {
            cellConcepto.setBackgroundColor(new BaseColor(240, 240, 240));
            cellMonto.setBackgroundColor(new BaseColor(240, 240, 240));
        }

        table.addCell(cellConcepto);
        table.addCell(cellMonto);
    }
}
