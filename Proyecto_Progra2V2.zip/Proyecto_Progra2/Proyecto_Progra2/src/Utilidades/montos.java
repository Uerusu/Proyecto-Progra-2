/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

/**
 *
 * @author edu04
 */
public class montos {
    
    
    // Deducciones del empleado
    public static final double DEDUCCION_CCSS = 0.1067;
    public static final double DEDUCCION_IVM = 0.0417;
    public static final double DEDUCCION_SEM = 0.0650;
    public static final double DEDUCCION_BANCO_POPULAR = 0.01;
    
    // Aportes patronales
    public static final double APORTE_CCSS = 0.2667;
    public static final double APORTE_IVM = 0.0708;
    public static final double APORTE_SEM = 0.1059;
    public static final double APORTE_INA = 0.015;
    public static final double APORTE_FCL = 0.03;
    public static final double APORTE_ASIGNACIONES = 0.05;
    
    // Tramos de impuesto sobre la renta 2024
    public static final double RENTA_BASE_LIBRE = 941000;
    public static final double RENTA_TRAMO1_LIMITE = 1405000;
    public static final double RENTA_TRAMO1_PORCENTAJE = 0.10;
    public static final double RENTA_TRAMO2_LIMITE = 2108000;
    public static final double RENTA_TRAMO2_PORCENTAJE = 0.15;
    public static final double RENTA_TRAMO3_LIMITE = 4215000;
    public static final double RENTA_TRAMO3_PORCENTAJE = 0.20;
    public static final double RENTA_TRAMO4_PORCENTAJE = 0.25;
    
    // Configuración de correo
    public static final String SMTP_HOST = "securemail.comredcr.com";
    public static final String SMTP_PORT = "465";
    public static final String EMAIL_FROM = "curso_progra2@comredcr.com";
    public static final String EMAIL_PASSWORD = "u6X1h1p9@";
    
    // Tipos de planilla
    public static final String PLANILLA_QUINCENAL = "QUINCENAL";
    public static final String PLANILLA_MENSUAL = "MENSUAL";
    
    private montos() {}
}


